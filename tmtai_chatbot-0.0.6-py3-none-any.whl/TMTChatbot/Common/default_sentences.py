DEFAULT_NONE_ANSWER = "{Bot@gender} chưa có thông tin"
