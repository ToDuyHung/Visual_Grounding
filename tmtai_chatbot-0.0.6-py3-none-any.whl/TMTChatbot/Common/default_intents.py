# EXTRACTED FROM USER AND CONVERSATION INFO
DEFAULT_TAG = "default"
USER_PROVIDE_DATA = "User@provide_data"
USER_HAS_MESSAGE = "User@has_message"
USER_MENTION_OBJECT = "User@mention_object"
USER_MENTION_OLD_OBJECT = "User@mention_old_object"
USER_MENTION_UNCLEAR_OBJECTS = "User@mention_unclear_object"
USER_MENTIONED_OBJECT = "User@mentioned_object"
USER_ASK_PRODUCT_INVENTORY = "User@request_product_inventory"

USER_BASE_MISSING_INFO = "Bot@user_missing_info"
USER_MULTI_VALUE = "Bot@user_multi_value"
BOT_MULTI_OBJECTS = "Bot@multi_objects"
BOT_PRODUCT_HAS_DISCOUNT = "Bot@product_has_discount"
BOT_ZERO_INVENTORY = "Bot@zero_inventory"
BOT_HAVE_INVENTORY = "Bot@have_inventory"
BOT_OBJECT_NOT_FOUND = "Bot@object_not_found"
BOT_INIT_NEW_BILL = "Bot@init_new_bill"
BOT_BILL_CONFIRMED = "Bot@bill_confirmed"
BOT_BILL_PROCESSING = "Bot@bill_processing"
BOT_BILL_EMPTY = "Bot@bill_empty"
BOT_BILL_VALID_PRODUCTS = "Bot@bill_valid_products"
BOT_NONE_CONFIRMED_BILL = "Bot@none_confimed_bill"
BOT_SINGLE_CONFIRMED_BILL = "Bot@single_confimed_bill"
BOT_MULTIPLE_CONFIRMED_BILLS = "Bot@multiple_confimed_bills"
BOT_NONE_OLD_BILL = "Bot@none_old_bill"
BOT_MULTIPLE_OLD_BILLS = "Bot@multiple_old_bills"

# TO BOT ACTION
BOT_CHECK_PRODUCT_HAS_DISCOUNT = "Bot@check_product_has_discount"

BOT_PROCESS_BILL = "Bot@process_bill"
BOT_ADD_PAYMENT_METHOD_RECOMMENDATIONS = "Bot@add_payment_method_recommendations"
BOT_ADD_BILL_PAYMENT_METHOD = "Bot@add_bill_payment_method"
BOT_ADD_BILL_PRODUCT = "Bot@add_bill_product"
BOT_ADD_CARE_PRODUCT = "Bot@add_care_product"
BOT_CANCEL_PRODUCT = "Bot@cancel_product"
BOT_CONFIRM_BILL = "Bot@confirm_bill"
BOT_USER_CANCEL_BILL = "Bot@user_cancel_bill"
BOT_UPDATE_PENDING_PAYMENT = "Bot@update_pending_payment"

BOT_ADD_OBJECT_RECOMMENDATIONS = "Bot@add_object_recommendations"
BOT_DROP_MULTIPLE_CHOICES = "Bot@drop_multiple_choices"
BOT_REFRESH_MULTIPLE_CHOICES = "Bot@refresh_multiple_choices"
BOT_PROCESS_MULTIPLE_CHOICES = "Bot@process_multiple_choices"
BOT_ADD_MULTIPLE_OBJECT_CHOICE_RECOMMENDATIONS = "Bot@add_multiple_object_choice_recommendations"
BOT_UPDATE_USER_OBJECT_CHOICE = "Bot@update_user_object_choice"

# billing + check object in bill unique
BOT_ADD_MULTIPLE_VALUE_CHOICE_CANDIDATES = "Bot@add_multiple_value_choice_candidates"
BOT_CHECK_BILL_PRODUCT_UNIQUE = "Bot@check_bill_product_unique"
BOT_BILL_PRODUCT_UNIQUE = "Bot@bill_product_unique"
BOT_BILL_PRODUCT_NOT_UNIQUE = "Bot@bill_product_not_unique"

BOT_CHECK_USER_SEND_PAYMENT = "Bot@check_user_send_payment"
BOT_USER_SEND_PAYMENT = "Bot@user_send_payment"

BOT_USER_CHOOSE_A_VALUE = "Bot@user_choose_a_value"
BOT_USER_CHOOSE_AN_OBJECT = "Bot@user_choose_an_object"
BOT_USER_UNCLEAR_CHOICE = "Bot@user_unclear_choice"
BOT_USER_WRONG_PHONE = "Bot@user_wrong_phone"

BOT_ANSWER_PRODUCT_QUESTION = "Bot@answer_product_question"
BOT_HAS_ANSWER = "Bot@has_answer"
BOT_CANNOT_ANSWER = "Bot@cannot_answer"

BOT_ITEM_IN_SHOP = "Bot@item_in_shop"
BOT_ITEM_OUT_SHOP = "Bot@item_out_shop"

BOT_PRODUCT_IMAGE_SEARCH_MODEL = "Bot@product_image_search_model"
BOT_USER_SEND_IMAGE = "Bot@user_send_image"
BOT_USER_SEND_IMAGE_TEXT = "Bot@user_send_image_text"

BOT_UPDATE_WEATHER_INFOR = "Bot@update_weather_infor"
BOT_USER_HAS_LOCATION = "Bot@user_has_location_weather"
BOT_USER_HAS_NO_LOCATION = "Bot@user_has_no_location_weather"
BOT_USER_HAS_TIME_WEATHER = "Bot@user_has_time_weather"
BOT_USER_HAS_NO_TIME_WEATHER = "Bot@user_has_no_time_weather"

# STATE: CANCEL BILL
BOT_CHECK_BILL_PRODUCT_TO_CANCEL = "Bot@check_bill_product_to_cancel"
BOT_ADD_DROP_PRODUCT_CHOICES = "Bot@add_drop_product_choices"
# use in state that user has one product in bill
USER_BILL_HAVE_ONE = "Bot@user_bill_have_one"
# use in state that user has many products in bill
USER_BILL_HAVE_PRODUCTS = "Bot@user_bill_have_products"
