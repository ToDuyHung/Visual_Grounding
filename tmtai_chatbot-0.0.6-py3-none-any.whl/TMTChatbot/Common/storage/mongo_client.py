import pymongo

from TMTChatbot.Common.common_keys import *
from TMTChatbot.Common.config import Config
from TMTChatbot.Schema.config.schema_config import BaseSchemaConfig
from TMTChatbot.Schema.objects.base_object import BaseObject
from TMTChatbot.Common.storage.base_storage import BaseStorage


class MongoConnector(BaseStorage):
    def __init__(self, config: Config = None):
        super(MongoConnector, self).__init__(config=config)
        self.config = config if config is not None else Config()
        self.mongo_connector = pymongo.MongoClient(host=self.config.mongo_host,
                                                   port=self.config.mongo_port,
                                                   username=self.config.mongo_username,
                                                   password=self.config.mongo_password)
        self.schema_cache = {}

    @staticmethod
    def __to_update_json(data, field_methods: dict = None):
        if field_methods is None:
            field_methods = {}
        output = {}
        for key, value in data.items():
            if key not in field_methods:
                method = "$set"
                if method not in output:
                    output[method] = {}
                output[method][key] = value
            else:
                method = f"${field_methods[key]}"
                if method not in output:
                    output[method] = {}
                if isinstance(value, list):
                    output[method][key] = {"$each": value}
        return output

    @staticmethod
    def __to_query_json(skip_fields: [str] = None):
        if skip_fields is None:
            return {}
        output = {}
        for key in skip_fields:
            output[key] = 0
        return output

    def get_database(self, storage_id: str):
        return f"{self.config.mongo_database}_{storage_id}"

    def _load_schema(self, data_object: BaseObject, storage_id: str, restrict: bool = False) -> dict:
        collection = self.mongo_connector[self.get_database(storage_id)][SCHEMA.capitalize()]
        if data_object.parent_class is None:
            output: dict = collection.find_one({CLASS: data_object.class_name()})
        else:
            output: dict = collection.find_one(
                {CLASS: data_object.class_name(), PARENT_CLASS: data_object.parent_class})
            if output is None and not restrict:
                output: dict = collection.find_one({CLASS: data_object.class_name()})

        if output is not None and OBJECT_ID in output:
            output[OBJECT_ID] = str(output[OBJECT_ID])
        return output

    def _store_schema(self, schema: BaseSchemaConfig, storage_id: str, upsert: bool = True):
        collection = self.mongo_connector[self.get_database(storage_id)][SCHEMA.capitalize()]
        if schema.parent_class is None:
            return collection.replace_one({CLASS: schema.class_name()}, schema.json, upsert=upsert)
        else:
            return collection.replace_one({CLASS: schema.class_name(), PARENT_CLASS: schema.parent_class},
                                          schema.json, upsert=upsert)

    def _load(self, class_name, object_id, storage_id: str, skip_fields: [str] = None):
        collection = self.mongo_connector[self.get_database(storage_id)][class_name]
        return collection.find_one({OBJECT_ID: object_id}, self.__to_query_json(skip_fields))

    def _load_all(self, class_name, storage_id, offset: int = None, limit: int = None, skip_fields: [str] = None):
        collection = self.mongo_connector[self.get_database(storage_id)][class_name]
        output = collection.find({}, self.__to_query_json(skip_fields))
        if offset:
            output = output.skip(offset)
        if limit:
            output = output.limit(limit)
        return list(output)

    def _load_from_description(self, class_name, storage_id, description, skip_fields: [str] = None):
        collection = self.mongo_connector[self.get_database(storage_id)][class_name]
        return collection.find_one(description, self.__to_query_json(skip_fields))

    def _save(self, data_object: BaseObject, storage_id: str, field_methods=None):
        """
        Update data_object to mongo database
        :param data_object: data object to be saved to database
        :param field_methods: some field use different update method. Default: "set". Accept: "push" for list
        :return: None
        """
        collection = self.mongo_connector[self.get_database(storage_id)][data_object.class_name()]
        json_data = data_object.json
        json_data = self.__to_update_json(json_data, field_methods)
        collection.update_one({OBJECT_ID: data_object.id}, json_data, upsert=True)

    def _load_relations(self, src_id: str, dst_id: str, class_name: str, storage_id: str):
        collection = self.mongo_connector[self.get_database(storage_id)][class_name]
        output = list(collection.find({REL_SRC: src_id, REL_DST: dst_id}))
        return output

    def _delete(self, data_object: BaseObject, storage_id: str):
        collection = self.mongo_connector[self.get_database(storage_id)][data_object.class_name()]
        collection.find_one_and_delete({OBJECT_ID: data_object.id})

    def _load_random(self, class_name: str, storage_id: str, limit: int, conditions: dict = None):
        if conditions is None:
            conditions = {}
        collection = self.mongo_connector[self.get_database(storage_id)][class_name]
        return list(collection.find(conditions).limit(limit))
