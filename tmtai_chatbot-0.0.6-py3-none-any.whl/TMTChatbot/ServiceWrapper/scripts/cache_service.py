import random

from TMTChatbot.Common.config import Config
from TMTChatbot.ServiceWrapper.services.base_cache_service import SocketCacheService


if __name__ == "__main__":
    import time
    _config = Config(cache_socket_host="localhost",
                     cache_socket_port="8080",
                     cache_socket_endpoint="getdata")
    cache_service = SocketCacheService(_config)
    time.sleep(1)
    while cache_service.client is None or not cache_service.client.connected:
        time.sleep(1)

    k = 0
    while True:
        _save_data = "bbb" + str(k) + 'xxx' + str(random.randint(0, 100))
        print("SAVED DATA", _save_data)
        a = time.time()
        cache_service.save(key=str(k), data=_save_data)
        print("SAVE TIME", time.time() - a)
        a = time.time()
        output = cache_service.search(text=str(k), size=5, exact=False)
        print("OUTPUT", output)
        print("GET TIME", time.time() - a)
        time.sleep(1)
        k += 1
        if k == 100:
            break
