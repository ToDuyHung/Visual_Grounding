import random
import websocket
from datetime import datetime
from uuid import uuid4, uuid5

from TMTChatbot.ServiceWrapper.scripts.websocket_mode import SocketMode


class STOMPWebsocket:
    def __init__(self, mode: SocketMode = SocketMode.RECEIVER):
        self.session_id = None
        self.client_id = None
        self.ws = None
        self.mode = mode
        self.connect()

    def init_id(self):
        self.client_id = str(random.randint(0, 1000000)) + str(int(datetime.now().timestamp()))
        self.session_id = uuid5(uuid4(), self.client_id)
        self.ws = websocket.create_connection(
            f"ws://localhost:8080/getdata/{self.client_id}/{self.session_id}/websocket")

    def transmit(self, message):
        if self.ws is None:
            self.init_id()
        self.ws.send(message)
        print("SEND", message)

    @property
    def connect_string(self):
        return '["CONNECT\\naccept-version:1.1,1.0\\nheart-beat:100,100\\n\\n\\u0000"]'

    def wait_for_response(self, specific_response: str = None):
        while True:
            d = self.ws.recv()
            print(d)
            if specific_response is not None:
                if d == specific_response:
                    return d
                else:
                    continue
            elif d != " ":
                return d
            else:
                continue

    def wait_connect_success(self):
        message = self.wait_for_response()
        print(message)

    def connect(self):
        self.init_id()
        websocket.enableTrace(True)
        ws = websocket.create_connection(f"ws://localhost:8080/getdata/{self.client_id}/{self.session_id}/websocket")
        self.wait_for_response("o")
        print("CONNECTION ESTABLISHED")
        self.transmit(self.connect_string)
        self.wait_connect_success()
        while True:
            print("Receiving data: ")
            d = ws.recv()
            print(d)


if __name__ == "__main__":
    socket = STOMPWebsocket(mode=SocketMode.RECEIVER)
