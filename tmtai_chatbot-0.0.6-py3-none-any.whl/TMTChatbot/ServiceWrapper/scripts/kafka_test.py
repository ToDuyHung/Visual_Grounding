import json
import time
from threading import Thread
from TMTChatbot.Schema.objects.common.data_model import BaseDataModel
from kafka import KafkaConsumer, KafkaProducer
from TMTChatbot.Common.config import Config


config = Config()
consumer = KafkaConsumer(config.kafka_publish_topic,
                         bootstrap_servers=config.kafka_bootstrap_servers,
                         auto_offset_reset=config.kafka_auto_offset_reset,
                         group_id=config.kafka_group_id)
producer = KafkaProducer(bootstrap_servers=config.kafka_bootstrap_servers)


def consume_job():
    for message in consumer:
        message = message.value.decode('ascii')
        message = message.replace("'", '"')
        message = json.loads(message)
        data = BaseDataModel.from_json(message)
        print(f'INPUT MESSAGE: {message["index"]}', data, "FROM ", config.kafka_publish_topic)


def produce_job():
    count = 0
    while True:
        in_data = BaseDataModel(index=str(count), data={})
        print("SEND", json.dumps(in_data.dict()), "TO ", config.kafka_consume_topic)
        producer.send(config.kafka_consume_topic, value=json.dumps(in_data.dict()).encode('utf-8'))
        time.sleep(0.1)
        count += 1


consume_worker = Thread(target=consume_job, daemon=True)
product_worker = Thread(target=produce_job, daemon=True)

consume_worker.start()
product_worker.start()
consume_worker.join()
product_worker.join()
