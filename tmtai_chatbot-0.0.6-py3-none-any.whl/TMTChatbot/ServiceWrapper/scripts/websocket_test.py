import random

import stomper as stomper
import websocket
from datetime import datetime
from uuid import uuid4, uuid5


def main():
    websocket.enableTrace(True)

    # Connecting to websocket
    ws = websocket.create_connection("ws://localhost:8080/getdata/690/2q0lfeeg/websocket")
    stomper.connect("aaa", "bbb", "ws://localhost:8080/getdata/690/2q0lfeeg/websocket")
    out = stomper.connect("", "", "")
    # print(out)
    ws.send(out)
    # Initate Stomp connection!

    # Subscribing to topic
    # client_id = str(random.randint(0, 1000))
    # sub = stomper.subscribe("/topic/greeting", client_id, ack='auto')
    # ws.send(["SUBSCRIBE\nid:sub-0\ndestination:/cache/get/8335\n\n\u0000"])
    # ws.send("SEND\ndestination:/app/getdata\ncontent-length:64\n\n{\"userId\":\"8335\",\"data\":{\"key\":\"xxx\",\"data\":\"xxx\",\"keyHash\":\"\"}}\u0000")
    #
    # # Sending some message
    # # ws.send(stomper.send("/app/greeting", "Hello there"))
    #
    # while True:
    #     print("Receiving data: ")
    #     d = ws.recv()
    #     print(d)
    #     if d == "o":
    #         break
    # ws.send('CONNECT\naccept-version:1.1,1.0\nheart-beat:10000,10000\n\n\u0000')


def aaa():

    websocket.enableTrace(True)
    client_id = str(random.randint(0, 100000))
    uid = uuid5(uuid4(), str(datetime.now().timestamp()))
    ws = websocket.create_connection(f"ws://localhost:8080/getdata/{client_id}/{uid}/websocket")
    while True:
        print("Receiving data: ")
        d = ws.recv()
        print(d)
        if d == "o":
            break
    ws.send('["CONNECT\\naccept-version:1.1,1.0\\nheart-beat:10000,10000\\n\\n\\u0000"]')
    while True:
        print("Receiving data: ")
        d = ws.recv()
        print(d)
        if d == "o":
            break
    ws.send('["SUBSCRIBE\\nid:sub-0\\ndestination:/cache/get/e7db\\n\\n\\u0000"]')
    while True:
        print("Receiving data: ")
        d = ws.recv()
        print(d)
    # Generate the connect command to tell the server about us:
    # print(msg)
    #
    # # Connecting to websocket
    # ws = websocket.create_connection("ws://localhost:8080/getdata/690/2q0lfeeg/websocket")
    # stomper.connect("aaa", "bbb", "ws://localhost:8080/getdata/690/2q0lfeeg/websocket")
    # out = stomper.connect("bob", "1234", "")
    # # print(out)
    # ws.send(out)
    # # >>> 'CONNECT\nlogin:bob\npasscode:1234\n\n\x00\n'
    #
    # # Send the message to the server, and you'll get a response like:
    # #
    # server_response = """CONNECTED
    # session:ID:snorky.local-49191-1185461799654-3:18
    # \x00
    # """
    #
    # # We can react to this using the state machine to generate a response.
    # #
    # # The state machine can handle the raw message:
    # response = responder.react(server_response)
    #
    # # or we could unpack the message into a dict and use it:
    # #
    # print(stomper.unpack_frame(response))


if __name__ == '__main__':
    aaa()
