from enum import Enum


class SocketMode(Enum):
    RECEIVER = 0
    PUBLISHER = 1
