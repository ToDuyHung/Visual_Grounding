from TMTChatbot.ServiceWrapper.external_service_wrapper import BaseExternalService
from TMTChatbot.Schema.objects.common.data_model import BaseDataModel
from TMTChatbot.Schema.objects.conversation.conversation import Conversation
from TMTChatbot.Common.config import Config


class DocQAService(BaseExternalService):
    def __init__(self, config: Config = None):
        super(DocQAService, self).__init__(config=config)
        self.session = None
        self.api_url = f"{self.config.doc_qa_url}/process"

    def _pre_process(self, input_data):
        return BaseDataModel(data=input_data)

    def _post_process(self, data: BaseDataModel) -> str:
        if data is not None:
            result = data.data.get("answer", "")
        else:
            result = ""
        return result

