import re
import json
from typing import List

from TMTChatbot.Common.common_keys import LOCATION, ADDRESS, DATE
from TMTChatbot.Common.common_phrases import DEFAULT_QUESTION_WORD
from TMTChatbot.Common.default_sentences import DEFAULT_NONE_ANSWER
from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton
from TMTChatbot.Schema.objects.conversation import Conversation
from TMTChatbot.Schema.objects.graph.graph_data import BillProduct, Product, BankAccount
from TMTChatbot.AlgoClients.graph_qa_service import GraphQAService
from TMTChatbot.AlgoClients.weather_service import WeatherService
from TMTChatbot.StateController.config.config import Config
from TMTChatbot.Common.common_key_mapping import KEY_MAPPING


def map_bill_info(conversation: Conversation, config: Config, key=None):
    return json.dumps(conversation.data.bill.info_schema, indent=4, ensure_ascii=False)


def map_bill_drop_product(conversation: Conversation, config: Config, key=None):
    confirmed_products = [product for product in conversation.data.bill.products if product.confirmed]
    if not confirmed_products:
        return None
    last_product = confirmed_products[-1]
    conversation.data.add_nodes([last_product])
    return last_product.name


def map_bill_products_number(conversation: Conversation, config: Config, key=None):
    return len([product for product in conversation.data.bill.products if product.confirmed])


def map_bill_number(conversation: Conversation, config: Config, key=None):
    return len(conversation.data.confirmed_bills)


def map_bill_delivery_status(conversation: Conversation, config: Config, key=None):
    return "đã đến kho trung chuyển"


def map_bill_payment(conversation: Conversation, config: Config, key=None):
    return str(int(conversation.data.bill.payment)) + " VNĐ"


def map_bill_payment_method(conversation: Conversation, config: Config, key=None):
    return str(json.dumps(conversation.data.bill.bank_account.info_schema, indent=4, ensure_ascii=False))


def map_user_size_shirt(conversation: Conversation, config: Config, key=None):
    return "L"


def map_user_size_jean(conversation: Conversation, config: Config, key=None):
    return "L"


def map_user_info(conversation: Conversation, config: Config, key=None):
    _, attr = key.split("@")
    user = conversation.user
    values = user.get_attr(attr)
    if values is not None and isinstance(values, list) and len(values) > 0:
        value = values[-1]
    else:
        value = None
    return value


def map_bot_gender(conversation: Conversation, config: Config, key=None):
    user = conversation.user
    values = user.get_attr("gender")
    if values is not None and isinstance(values, list) and len(values) > 0:
        value = values[-1]
    else:
        value = None
    return value


def map_shop_info(conversation: Conversation, config: Config, key=None):
    _, attr = key.split("@")
    shop = conversation.shop
    if attr == "name" and shop.name is not None:
        values = [shop.name]
    else:
        values = shop.get_attr(attr)
    if values is not None and isinstance(values, list) and len(values) > 0:
        value = values[-1]
    else:
        value = None
    return value


def map_shop_showroom(conversation: Conversation, config: Config, key=None):
    shop = conversation.shop
    values = shop.get_attr("showroom")
    return "* ".join(values)


def map_product_info(conversation: Conversation, config: Config, key=None):
    _, attr = key.split("@")
    products = conversation.data.get_previous_node(node_class=Product.class_name())
    if len(products) == 0:
        return f"<ERROR PRODUCT {attr}>"
    else:
        product = products[0]
    if attr == "name":
        values = [product.name]
    else:
        values = product.get_attr(attr)
    if values is not None and isinstance(values, list) and len(values) > 0:
        value = values[-1]
    else:
        value = None

    if value is None:
        # TODO how to response unknown questions ????
        graph_qa_service = GraphQAService(config=config)
        value = graph_qa_service.custom_question(conversation,
                                                 question=f"{KEY_MAPPING.get(attr.lower())} "
                                                          f"{DEFAULT_QUESTION_WORD}")
    if value is None or value == "":
        value = DEFAULT_NONE_ANSWER
    return value


def map_product_image_url(conversation: Conversation, config: Config, key=None):
    products = conversation.data.get_previous_node()
    if len(products) == 0:
        return f"<ERROR PRODUCT> image_url"
    else:
        product = products[0]
    values = product.image_urls
    if values is not None and isinstance(values, list) and len(values) > 0:
        value = f"image {values[-1]}"
    else:
        value = None
    return value


def map_product_inventory(conversation: Conversation, config: Config = None, key=None):
    return True


def map_product_general_info(conversation: Conversation, config: Config, key=None):
    # graph_qa_service = GraphQAService(config=config)
    # product_info = graph_qa_service(conversation)
    # if product_info is None or product_info == "":
    #     product_info = DEFAULT_NONE_ANSWER
    # return product_info
    return conversation.current_state.message.answer_infor


def map_product_recommendation(conversation: Conversation, config: Config, key=None):
    if conversation.current_state.has_user_pending_choices:
        products = conversation.current_state.multiple_choices
    else:
        products = conversation.data.get_previous_node(node_class=Product.class_name(), return_latest=False,
                                                       k=config.num_recommendation)
    return " * ".join([product.image_description for product in products])


def map_drop_product_recommendation(conversation: Conversation, config: Config, key=None):
    products = conversation.data.bill.products
    return " và ".join([product.name for product in products if product.confirmed])


def map_product_multi_values_attr(conversation: Conversation, config: Config, key=None):
    products = conversation.data.get_previous_node(node_class=Product.class_name())
    if len(products) == 0:
        return
    else:
        product = products[0]
    bill_product: BillProduct = conversation.data.bill.get_product(product)
    if bill_product is not None:
        attr = bill_product.multiple_value_attribute
    else:
        attr = None
    if attr is not None:
        return attr
    return "<ERROR attr>"


def map_product_multi_values(conversation: Conversation, config: Config, key=None):
    products = conversation.data.get_previous_node(node_class=Product.class_name())
    if len(products) == 0:
        return
    else:
        product = products[0]
    bill_product: BillProduct = conversation.data.bill.get_product(product)
    if bill_product is not None:
        attr = bill_product.multiple_value_attribute
        if attr is not None:
            values = bill_product.get_attr(attr)
            return ", ".join(values)
    return "<ERROR>"


def map_unclear_products(conversation: Conversation, config: Config, key=None):
    k = 3
    products = conversation.data.get_previous_node(node_class=Product.class_name())[:k]
    return "* ".join([product.image_description for product in products])


def map_weather_infor(conversation: Conversation, config: Config, key=None):
    weather_service = WeatherService(config=config)
    weather_infor = weather_service(input_data=conversation)
    _, attr = key.split("@")
    if attr == DATE:
        return ", ".join([weather.date for weather in weather_infor])
    elif attr == LOCATION:
        return ", ".join([weather.location for weather in weather_infor])
    else:
        descriptions = {f"{weather.location} ngày {weather.date}": {attr: ",".join(value)
                                                                    for attr, value in weather.json_attributes.items()}
                        for weather in weather_infor}
        return json.dumps(descriptions, indent=4, ensure_ascii=False)


def map_chosen_bank_account(conversation: Conversation, config: Config, key=None):
    bank_accounts: List[BankAccount] = conversation.data.get_previous_node(node_class=BankAccount.class_name())
    if len(bank_accounts) == 0:
        return ""
    descriptions = bank_accounts[0].info_schema
    return json.dumps(descriptions, indent=4, ensure_ascii=False)


def map_recommend_full_payment_methods(conversation: Conversation, config: Config, key=None):
    bank_accounts = conversation.shop.bank_accounts
    return json.dumps([bank_account.info_schema for bank_account in bank_accounts])


class ValueMapping(BaseServiceSingleton):
    def __init__(self, config: Config = None):
        super(ValueMapping, self).__init__(config=config)
        self.mapping_funcs = {
            "Bot@gender": map_bot_gender,
            "Bill@info": map_bill_info,
            "Bill@number": map_bill_number,
            "Bill@delivery_status": map_bill_delivery_status,
            "Bill@payment": map_bill_payment,
            "Bill@payment_method": map_bill_payment_method,
            "Bill@drop_product": map_bill_drop_product,
            "Bill@product_number": map_bill_products_number,
            "User@size_shirt": map_user_size_shirt,
            "User@size_jean": map_user_size_jean,
            "User@*": map_user_info,
            "Product@info": map_product_general_info,
            "Product@inventory": map_product_inventory,
            "Product@*": map_product_info,
            "Product@recommendation": map_product_recommendation,
            "Product@recommend_drop_products": map_drop_product_recommendation,
            "Product@current_unclear": map_unclear_products,
            "Product@milti_values_attr": map_product_multi_values_attr,
            "Product@multi_values": map_product_multi_values,
            "Product@image_url": map_product_image_url,
            "Shop@*": map_shop_info,
            "Shop@showroom": map_shop_showroom,
            "Weather@info": map_weather_infor,
            "Weather@*": map_weather_infor,
            "Shop@chosen_bank_account": map_chosen_bank_account,
            "Shop@recommend_full_payment_methods": map_recommend_full_payment_methods
        }

    def add_mapping_func(self, key, func):
        self.mapping_funcs[key] = func

    @staticmethod
    def map_product_info(conversation: Conversation, config: Config):
        graph_qa_service = GraphQAService(config=config)
        product_info = graph_qa_service(conversation)
        return product_info

    @staticmethod
    def get_mapping_key(message: str):
        output = list(set(re.findall(r'(?<=\{)(\S+)(?=\})', message)))
        if "Bill@info" in output:
            output.remove("Bill@info")
            output = ["Bill@info", *output]
        return set(output)

    def get_mapping_func(self, key):
        mapping_func = self.mapping_funcs.get(key)
        if mapping_func is None:
            key_subject, _ = key.split("@")
            for mapping_func_name, mapping_func in self.mapping_funcs.items():
                subject, attr = mapping_func_name.split("@")
                if subject == key_subject and attr == "*":
                    return mapping_func
        else:
            return mapping_func

    def get_mapping_value(self, key, message: str, conversation: Conversation, config: Config):
        mapping_func = self.get_mapping_func(key)
        if mapping_func is not None:
            mapping_info, mapped_key = conversation.current_state \
                .state_action_config.get_info_mapping(key)
            if mapping_info is not None:
                mapped_value = mapping_func(conversation, config, key=key)
                mapped_template = mapping_info.get_mapping_template(key=key, mapped_key=mapped_key,
                                                                    mapped_value=mapped_value)
                mapped_value = mapped_template.format(**{key: mapped_value})
                if mapped_value is not None:
                    message = message.replace("{" + key + "}", mapped_value)
            return message
        else:
            return message

    def __call__(self, message: str, conversation: Conversation):
        count = 0
        while count < 5:
            count += 1
            keys = self.get_mapping_key(message)
            if len(keys) == 0:
                break
            for key in keys:
                message = self.get_mapping_value(key, message, conversation, self.config)
        return message
