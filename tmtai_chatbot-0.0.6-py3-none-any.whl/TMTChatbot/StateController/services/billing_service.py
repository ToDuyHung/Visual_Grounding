from datetime import datetime

from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton
from TMTChatbot.AlgoClients.bill_image_service import BillImageService
from TMTChatbot.StateController.config.config import Config
from TMTChatbot.Common.default_intents import *
from TMTChatbot.Schema.objects.conversation.conversation import Conversation
from TMTChatbot.Schema.objects.graph.graph_data import BillProduct, Product, BankAccount
from TMTChatbot.Schema.common.product_types import PaymentStatus


class BillingManager(BaseServiceSingleton):
    def __init__(self, config: Config = None):
        super(BillingManager, self).__init__(config=config)
        self.bill_image_service = BillImageService(config=config)

    @staticmethod
    def cancel_product(conversation: Conversation):
        """
        Turn current Product status into CANCELED
        :param conversation:
        :return:
        """
        products = conversation.data.get_previous_node(node_class=Product.class_name())
        if len(products) == 0:
            return
        else:
            product = products[0]
        bill = conversation.data.bill
        bill_product: BillProduct = BillProduct.from_product(product)
        bill_product = bill.get_product(bill_product)
        bill_product.cancel()

    @staticmethod
    def check_bill_product_to_cancel(conversation: Conversation):
        products = conversation.data.bill.confirmed_products
        if len(products) == 1:
            conversation.current_state.update_intents([USER_BILL_HAVE_ONE])
        else:
            conversation.current_state.update_intents([USER_BILL_HAVE_PRODUCTS])

    @staticmethod
    def add_care_product(conversation: Conversation):
        """
        Add current Product to bill => Auto care product if product is not confirmed
        :param conversation:
        :return:
        """
        if BOT_USER_CHOOSE_AN_OBJECT in conversation.current_state.intent_set:
            product = conversation.current_state.message.multiple_choices[0]
            conversation.data.add_nodes([product])
        else:
            products = conversation.data.get_previous_node(node_class=Product.class_name())
            if len(products) == 0:
                return
            else:
                product = products[0]
        bill = conversation.data.bill
        bill_product: BillProduct = BillProduct.from_product(product)
        bill_product = bill.add_product(bill_product)
        bill_product.care()

    @staticmethod
    def add_billing_product(conversation: Conversation):
        """
        Add current Product to bill => Auto confirm
        :param conversation:
        :return:
        """
        products = conversation.data.get_previous_node(node_class=Product.class_name())
        products = [p for p in products if isinstance(p, Product)]
        if len(products) == 0:
            return
        else:
            product = products[0]
        bill = conversation.data.bill
        bill_product: BillProduct = BillProduct.from_product(product)
        bill_product = bill.add_product(bill_product)
        current_time = datetime.now().timestamp()
        bill_product.set_mentioned_time(current_time)
        if not bill_product.is_canceled:
            bill_product.confirm()

    @staticmethod
    def add_bill_payment_method(conversation: Conversation):
        bank_accounts = conversation.data.get_previous_node(node_class=BankAccount.class_name())
        if len(bank_accounts) == 0:
            return
        else:
            bank_account = bank_accounts[0]
            bill = conversation.data.bill
            bill.bank_account = bank_account

    @staticmethod
    def add_payment_method_recommendations(conversation: Conversation):
        current_state = conversation.current_state
        if current_state is None:
            return
        current_state.multiple_choices = conversation.shop.bank_accounts

    @staticmethod
    def process_bill(conversation: Conversation):
        if conversation.data.bill is None:
            conversation.data.init_bill()
        conversation.data.bill.processing()

    @staticmethod
    def confirm_bill(conversation: Conversation):
        bill = conversation.data.bill
        bill.confirm()

    @staticmethod
    def cancel_bill(conversation: Conversation):
        bill = conversation.data.bill
        bill.cancel()

    @staticmethod
    def new_bill(conversation: Conversation):
        conversation.data.init_bill()

    @staticmethod
    def update_pending_payment(conversation: Conversation):
        bill = conversation.data.bill
        bill.payment_status = PaymentStatus.PENDING

    @staticmethod
    def update_done_payment(conversation: Conversation):
        bill = conversation.data.bill
        bill.payment = PaymentStatus.DONE

    @staticmethod
    def check_user_send_payment(conversation: Conversation):
        """
        Check if user send and image of bill with correct amount of money
        :param conversation:
        :return:
        """
        conversation.current_state.message.update_intents([BOT_USER_SEND_PAYMENT])

    @staticmethod
    def check_product_discount(conversation: Conversation):
        """
        If the product is unique, then check if there is any discount of this product
        :param conversation:
        :return:
        """
        products = conversation.data.get_previous_node()
        if len(products) == 0:
            return
        elif len(products) > 1:
            return
        else:
            product = products[0]
            for key in ["discount", "giảm_giá"]:
                discount = product.get_attr(key)
                if discount is not None and len(discount) > 0:
                    conversation.current_state.message.update_intents([BOT_PRODUCT_HAS_DISCOUNT])
                    return
