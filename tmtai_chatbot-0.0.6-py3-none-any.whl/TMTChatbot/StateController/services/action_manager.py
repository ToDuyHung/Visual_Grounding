from typing import Dict, Callable

from TMTChatbot.AlgoClients.weather_service import WeatherService
from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton
from TMTChatbot.StateController.services.information_extractor import BaseInformationExtractor
from TMTChatbot.StateController.services.value_mapping import ValueMapping
from TMTChatbot.StateController.services.bot_intent import BotIntent
from TMTChatbot.StateController.services.billing_service import BillingManager
from TMTChatbot.StateController.services.multiple_choice_manager import MultipleChoiceManager
from TMTChatbot.StateController.services.qa_service import QAService
from TMTChatbot.StateController.config.config import Config
from TMTChatbot.StateController.services.product_search_manager import ProductSearchManager
from TMTChatbot.StateController.services.recommendation_manager import RecommendationManager
from TMTChatbot.Schema.objects.conversation import Conversation
from TMTChatbot.Common.default_intents import *


class ActionManager(BaseServiceSingleton):
    def __init__(self, config: Config):
        super(ActionManager, self).__init__(config=config)
        self.information_extractor = BaseInformationExtractor(config=config)
        self.bot_intent_extractor = BotIntent(config=config)
        self.value_mapper = ValueMapping(config=config)
        self.billing_manager = BillingManager(config=config)
        self.multiple_choice_manager = MultipleChoiceManager(config=config)
        self.product_search_manager = ProductSearchManager(config=config)
        self.recommendation_manager = RecommendationManager(config=config)
        self.qa_services = QAService(config=config)
        self.weather_services = WeatherService(config=config)
        self.actions: Dict[str, Callable[[Conversation], ...]] = {
            BOT_CHECK_PRODUCT_HAS_DISCOUNT: self.billing_manager.check_product_discount,

            BOT_ADD_MULTIPLE_VALUE_CHOICE_CANDIDATES: self.multiple_choice_manager.add_multiple_value_choices,
            BOT_PROCESS_MULTIPLE_CHOICES: self.multiple_choice_manager.process_state,
            BOT_DROP_MULTIPLE_CHOICES: self.multiple_choice_manager.drop_multiple_choices,
            BOT_REFRESH_MULTIPLE_CHOICES: self.multiple_choice_manager.refresh_multiple_choices,
            BOT_ADD_OBJECT_RECOMMENDATIONS: self.recommendation_manager.add_product_recommendations,
            BOT_ADD_MULTIPLE_OBJECT_CHOICE_RECOMMENDATIONS: self.recommendation_manager.add_product_multiple_choices,

            BOT_ADD_BILL_PRODUCT: self.billing_manager.add_billing_product,
            BOT_ADD_CARE_PRODUCT: self.billing_manager.add_care_product,
            BOT_ADD_PAYMENT_METHOD_RECOMMENDATIONS: self.billing_manager.add_payment_method_recommendations,
            BOT_ADD_BILL_PAYMENT_METHOD: self.billing_manager.add_bill_payment_method,
            BOT_CANCEL_PRODUCT: self.billing_manager.cancel_product,
            BOT_CONFIRM_BILL: self.billing_manager.confirm_bill,
            BOT_PROCESS_BILL: self.billing_manager.process_bill,
            BOT_UPDATE_PENDING_PAYMENT: self.billing_manager.update_pending_payment,
            BOT_CHECK_USER_SEND_PAYMENT: self.billing_manager.bill_image_service,

            BOT_ANSWER_PRODUCT_QUESTION: self.qa_services.answer_user_product_question,

            BOT_PRODUCT_IMAGE_SEARCH_MODEL: self.product_search_manager.node_product_image_search,
            BOT_UPDATE_WEATHER_INFOR: self.weather_services.update_weather_infor,

            BOT_CHECK_BILL_PRODUCT_TO_CANCEL: self.billing_manager.check_bill_product_to_cancel,
            BOT_ADD_DROP_PRODUCT_CHOICES: self.multiple_choice_manager.add_drop_product_choices
        }

    def add_action(self, action_name, action_function):
        if action_name in self.actions:
            raise ValueError(f"{action_name} already exist. Please use different action_name")
        self.actions[action_name] = action_function

    def map_bot_expectation(self, conversation: Conversation):
        self.information_extractor.map_bot_expectation(conversation)

    def default_global_actions(self, conversation: Conversation):
        pass

    def default_pre_actions(self, conversation: Conversation, is_new_action: bool = False,
                            mapping_info_only: bool = False):
        """
        Some task must be done in every conversation turn to extract basic information from users
        :param conversation:
        :param is_new_action:
        :param mapping_info_only:
        :return:
        """
        if mapping_info_only:
            self.information_extractor.mapping_info(conversation)
        else:
            self.information_extractor.information_extraction(conversation, is_new_action)
            self.information_extractor.mapping_info(conversation, is_new_action)
            self.bot_intent_extractor.extract_state_based_intents(conversation)

    def make_pre_actions(self, conversation: Conversation, is_new_action: bool = False,
                         mapping_info_only: bool = False):
        """
        Looking for action in PRE ACTIONS to execute the appropriate function
        :param conversation:
        :param is_new_action:
        :param mapping_info_only:
        :return:
        """
        self.default_pre_actions(conversation=conversation, is_new_action=is_new_action,
                                 mapping_info_only=mapping_info_only)
        current_action = conversation.current_action
        if current_action is not None:
            for pre_action in current_action.pre_actions.values():
                if pre_action.tag in self.actions:
                    func = self.actions[pre_action.tag]
                    func(conversation)

    def make_post_actions(self, conversation: Conversation):
        """
        Looking for action in POST ACTIONS to execute the appropriate function
        :param conversation:
        :return:
        """
        current_action = conversation.current_action
        if current_action is not None:
            for post_action in current_action.post_actions.values():
                if post_action.tag in self.actions:
                    func = self.actions[post_action.tag]
                    func(conversation)

    def make_current_action(self, conversation: Conversation):
        """
        Looking for action in CURRENT DONE BRANCH to execute the appropriate function
        :param conversation:
        :return:
        """
        current_action = conversation.current_action
        if current_action is not None:
            current_branch = current_action.current_branch
            if current_branch is not None:
                print("POST ACTIONS", current_action.name, current_branch.post_actions.values())
                for current_action in current_branch.post_actions.values():
                    if current_action.tag in self.actions:
                        func = self.actions[current_action.tag]
                        func(conversation)
