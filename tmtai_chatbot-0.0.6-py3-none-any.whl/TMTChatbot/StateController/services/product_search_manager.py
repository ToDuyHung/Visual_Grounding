from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton
from TMTChatbot.AlgoClients.node_product_image_search import NodeProductImageSearch
from TMTChatbot.StateController.config.config import Config
from TMTChatbot.Schema.objects.conversation.conversation import Conversation
from TMTChatbot.Common.default_intents import *


class ProductSearchManager(BaseServiceSingleton):
    def __init__(self, config: Config = None):
        super(ProductSearchManager, self).__init__(config=config)
        self.node_product_image_search = NodeProductImageSearch(config=config)

    @staticmethod
    def check_url(conversation: Conversation):
        pre_actions = []
        if conversation.current_action is not None:
            pre_actions = [pre_action.tag for pre_action in conversation.current_action.pre_actions.values()]
        if BOT_CHECK_USER_SEND_PAYMENT not in pre_actions and \
                (len(conversation.pending_message.urls) > 0 or conversation.pending_message.base64_img):
            return True
        else:
            return False


