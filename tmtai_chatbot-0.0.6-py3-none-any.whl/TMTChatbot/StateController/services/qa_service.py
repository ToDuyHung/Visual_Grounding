from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton
from TMTChatbot.StateController.config.config import Config
from TMTChatbot.AlgoClients.graph_qa_service import GraphQAService
from TMTChatbot.AlgoClients.doc_qa_service import DocQAService
from TMTChatbot.Common.default_intents import *
from TMTChatbot.Schema.objects.conversation.conversation import Conversation


class QAService(BaseServiceSingleton):
    def __init__(self, config: Config = None):
        super(QAService, self).__init__(config=config)
        self.graph_qa_service = GraphQAService(config=config)
        # self.doc_qa_service = DocQAService(config=config)

    def answer_user_product_question(self, conversation: Conversation):
        answer = self.graph_qa_service(conversation)
        # if answer is None or answer == "":
        #     answer = self.doc_qa_service(conversation)
        conversation.current_state.message.answer_infor = answer
        if answer is None or answer == "":
            conversation.current_state.message.update_intents([BOT_CANNOT_ANSWER])
        else:
            conversation.current_state.message.update_intents([BOT_HAS_ANSWER])

    def answer_custom_question(self, conversation: Conversation):
        pass
