import json

from TMTChatbot.StateController.base_state_controller import BaseStateController
from TMTChatbot.Schema.objects.conversation.conversation import Message, Response
from TMTChatbot.Schema.objects.conversation.state_action_config import ScriptConfig

if __name__ == "__main__":
    from TMTChatbot.StateController.config import ConversationConfig

    _config = ConversationConfig(intent_url="http://172.29.13.24:20221",
                                 graph_qa_url="http://172.29.13.24:20224",
                                 ner_url="http://172.29.13.24:20220",
                                 doc_qa_url="http://172.29.13.24:20227",
                                 node_search_url="http://172.29.13.24:20223",
                                 # node_search_url="http://localhost:8080",
                                 multiple_choice_url="http://172.29.13.24:20230",
                                 # multiple_choice_url="http://localhost:8080",
                                 mongo_host="172.29.13.24",
                                 mongo_port=20253,
                                 address_url="http://address-dev.ai.tmtco.org/process/ner_address",
                                 node_image_search_url="http://172.29.13.24:20233",
                                 bill_image_service_url="http://172.29.13.24:20232",
                                 weather_url="http://172.29.13.24:20231",
                                 # weather_url="http://localhost:8080",
                                 response_delimiter="\n")
    controller = BaseStateController(config=_config)
    # script_config = ScriptConfig.default(controller.storage)
    # data = script_config.json
    # print(data)
    #
    # import sys
    # sys.exit()
    # script_config = json.load(
    #     open("C:/nguyenpq/workspace/ChatBot/Common/TMTChatbot/StateController/scripts/chatbot_script/script_temp.json",
    #          "r", encoding="utf8"))
    # script_config = ScriptConfig.from_json(data=script_config, storage=controller.storage)
    # script_config.save(force=True)

    _message = Message(message="xin chào", storage=controller.storage, storage_id="test",
                       user_id="nguyenpq", shop_id="f853c5c9-b7a5-5220-82a1-1c1a94777e4e")
    controller.refresh_conversation(_message)

    while True:
        response: Response = controller(message=_message, script_config=None)
        print("Response: ", response.message)
        user_message = input("Message:")
        _message = Message(message=user_message, storage=controller.storage, storage_id="test",
                           user_id="nguyenpq", shop_id="f853c5c9-b7a5-5220-82a1-1c1a94777e4e")
