from TMTChatbot import Product

import asyncio

import requests
import json
from tqdm import tqdm
import os

from concurrent.futures import ThreadPoolExecutor

from TMTChatbot.StateController.config import ConversationConfig
from TMTChatbot.Common.storage.mongo_client import MongoConnector

# url = "http://172.28.0.23:35432/api/file/upload-file-local"
url = "https://files.tmtco.dev/api/v2/Media/upload-files"


product_search_url = "http://172.29.13.24:20233/process/update_shop_data_image"
# product_search_url = "http://172.29.5.139:8080/process/update_shop_data_image"

data_folder = "//172.29.13.24/tmtaishare/Data/shopee"

# image_ids = {}
# for product in tqdm(os.listdir(data_folder)):
#     if "shopee" in product:
#         continue
#     product_path = os.path.join(data_folder, product, "image")
#     product_ids = os.listdir(product_path)
#     for product_id in product_ids:
#         image_ids[product_id] = os.path.join(product_path, product_id)
#
# json.dump(image_ids, open("./cache.json", "w", encoding="utf8"), ensure_ascii=False)

image_ids = json.load(open("./cache.json", "r", encoding="utf8"))


def update_product(product_, p_id):
    if len(product_.image_urls) == 0:
        for image_name in os.listdir(image_ids[p_id]):
            """
            :param files: (optional) Dictionary of ``'name': file-like-objects`` (or ``{'name': file-tuple}``) for multipart encoding upload.
            ``file-tuple`` can be a 2-tuple ``('filename', fileobj)``, 3-tuple ``('filename', fileobj, 'content_type')``
            or a 4-tuple ``('filename', fileobj, 'content_type', custom_headers)``, where ``'content-type'`` is a string
            defining the content type of the given file and ``custom_headers`` a dict-like object containing additional headers
            to add for the file.
            """

            def task(i_name):
                headers = {
                    'accept': 'text/plain',
                    'App-Id': 'tpos.vn',
                    'App-Secret': 'cjgMuAM3f755NqnVs4WE9CvkLyliKfX8',
                    'App-Folder': 'tpos'
                }

                files = {
                    'Files': (f'demo_shop_{p_id}-{i_name.replace("_", "-")}', open(os.path.join(image_ids[p_id], i_name),
                                                                                   'rb').read(), 'image/jpeg'),
                    'FolderPath': (None, 'team-ai'),
                    'Overwrite': (None, 'true'),
                    'Tenant': (None, ''),
                }

                result = requests.post('https://files.tmtco.dev/api/v2/Media/upload-files', headers=headers, files=files)

                result = result.json()
                if result is not None and len(result) > 0:
                    return result[0]["urlImageProxy"]
                else:
                    return None

            output = task(image_name)
            if output is not None:
                product_.image_urls.append(output)
    payload = {
        "index": "a;lkalsd",
        "data": [
            {
                "storage_id": "test",
                "_id": product_.id,
                "image_urls": product_.image_urls
            }
        ]
    }
    # payload = {
    #     "index": "a;lkalsd",
    #     "data": [
    #         {
    #             "storage_id": "test",
    #             "_id": "018b873d3e2f1ae7af9f4988c3b5e78c",
    #             "image_urls": [
    #                 "https://tmt-img.dev.tmtco.org/twreuEyZM7VpRboyILXiijWkxzNwcBeSYNMjz9fDRtM/rs::::1/g:no/q:100/plain/tpos/team-ai/demo_shop_018b873d3e2f1ae7af9f4988c3b5e78c-0.jpg",
    #                 "https://tmt-img.dev.tmtco.org/KJeAOeaHX27dMYbbCk46YwUOHyEoULO1hJHz4fg3d8E/rs::::1/g:no/q:100/plain/tpos/team-ai/demo_shop_018b873d3e2f1ae7af9f4988c3b5e78c-1.jpg",
    #                 "https://tmt-img.dev.tmtco.org/gYyltTqxrLuNZDLLvVOG0MNc_cTa7_AoogNigYwByIA/rs::::1/g:no/q:100/plain/tpos/team-ai/demo_shop_018b873d3e2f1ae7af9f4988c3b5e78c-2.jpg",
    #                 "https://tmt-img.dev.tmtco.org/NrwWP58EpvI8GPopU6Ne9uXhNGw2bbQMz9UBKOrJCaA/rs::::1/g:no/q:100/plain/tpos/team-ai/demo_shop_018b873d3e2f1ae7af9f4988c3b5e78c-3.jpg",
    #                 "https://tmt-img.dev.tmtco.org/mvAelNuNDN161cbKt-kc1SxMQPYQ4yXXxfbzHnmZjIk/rs::::1/g:no/q:100/plain/tpos/team-ai/demo_shop_018b873d3e2f1ae7af9f4988c3b5e78c-4.jpg"]
    #
    #         }
    #     ]
    # }

    # headers = {
    #     'Content-Type': 'application/json'
    # }
    session = requests.session()
    response = session.post(product_search_url, json=payload)
    print("PRODUCT SEARCH", response.text)
    # product_.save(force=True)

    print(product_.id, product_.image_urls)
    return p_id


def main():
    executor = ThreadPoolExecutor(max_workers=20)
    _config = ConversationConfig(intent_url="http://172.29.13.24:20221",
                                 graph_qa_url="http://172.29.13.24:20224",
                                 ner_url="http://172.29.13.24:20220",
                                 doc_qa_url="http://172.29.13.24:20227",
                                 node_search_url="http://172.29.13.24:20223",
                                 multiple_choice_url="http://172.29.13.24:20230",
                                 mongo_host="172.29.13.24",
                                 mongo_port=20253,
                                 address_url="http://address.ai.tmtco.org/process/ner_address",
                                 response_delimiter="\n")
    storage = MongoConnector(config=_config)

    storage_id = "test"
    shop_data = json.load(
        open("C:/nguyenpq/workspace/ChatBot/Common/TMTChatbot/StateController/scripts/demo/product_information.json",
             "r",
             encoding="utf8"))

    jobs = []
    for product_data in tqdm(shop_data):
        for attr in list(product_data["attributes"]):
            new_attr = attr.strip().lower().replace(" ", "_")
            if new_attr != attr:
                product_data["attributes"][new_attr] = product_data["attributes"][attr]
                del product_data["attributes"][attr]
        product = Product.from_json(product_data)
        product.storage_id = storage_id
        product = Product.from_json(product.static_info, storage=storage)
        product_id = product.id
        if product_id not in image_ids:
            continue

        jobs.append(executor.submit(update_product, product, product_id))
        break

    # pbar = tqdm(total=len(p_groups))
    # for f in asyncio.as_completed(p_groups):
    #     value = await f
    #     pbar.set_description(value)
    #     pbar.update(1)
    # all_p_groups = asyncio.gather(*p_groups)
    # p_results = loop.run_until_complete(all_p_groups)
    # print(p_results)
    for job in tqdm(jobs):
        result = job.result()
        print(result)


if __name__ == "__main__":
    # asyncio.run(main())
    main()
