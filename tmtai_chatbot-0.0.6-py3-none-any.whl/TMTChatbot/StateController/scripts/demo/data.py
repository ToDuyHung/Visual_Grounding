data = {
    "index": "a;lkalsd",
    "data": {
        "intents": [
            {
                "tag": "User@request_product_inventory",
                "patterns": [
                    "đầm lovito còn không em",
                    "mẫu trên còn không em",
                    "bên mình còn không shop",
                    "áo da còn không em",
                    "giày mlb còn không em",
                    "đầm maxi còn không em",
                    "mũ hiện còn bán không",
                    "giày sneaker còn không",
                    "giày sneaker còn bán không em",
                    "có giày sneaker ko shop",
                    "đầm lovito còn không em",
                    "mẫu trên còn không em",
                    "bên mình còn không shop",
                    "áo da còn không em",
                    "giày mlb còn không em",
                    "đầm maxi còn không em",
                    "mũ hiện còn bán không",
                    "giày sneaker còn không",
                    "giày sneaker còn bán không em",
                    "có giày sneaker ko shop",
                    "[ sản phẩm ] còn không shop",
                    "[ sản vật ] còn ko",
                    "[ sản vật ] hiện còn bán ko",
                    "[ sản phẩm ] còn không em",
                    "[ sản vật ] hiện nay còn không á em"
                ]
            },
            {
                "tag": "User@request_product_info",
                "patterns": [
                    "màu gì",
                    "sản xuất ở đâu",
                    "hàng có về lại không",
                    "mẫu này cũng hết hả em",
                    "có màu khác không",
                    "bạn có thể báo giá mẫu này k ạ",
                    "bộ nào bao nhiêu vậy shop",
                    "vải đó chất liệu gì vậy shop",
                    "size l tầm bao nhiêu kg vừa ạ",
                    "đầm lovito giá nhiêu vậy",
                    "đầm lovito màu gì ấy",
                    "giá nhiêu",
                    "đầm này giá nhiêu",
                    "sản phẩm này giá nhiêu",
                    "chất liệu gì ấy",
                    "xuất xứ ở đâu vậy em",
                    "chiều dài tay áo như thế nào",
                    "xuất xứ đâu",
                    "à giày xuất xứ đâu á em",
                    "giảm giá bao nhiêu",
                    "sản phẩm này giảm giá nhiêu vậy",
                    "giảm giá nhiêu vậy",
                    "xuất xứ đâu",
                    "mặc khi nào thì hợp vậy em",
                    "mặc lúc nào thì hợp vậy em",
                    "lúc nào mặc thì hợp",
                    "mặc dịp nào vậy",
                    "đầm này nên mặc lúc nào ta",
                    "đầm maxi có những kiểu nào nhỉ",
                    "có những kiểu nào",
                    "có các kiểu dáng nào"
                ]
            },
            {
                "tag": "User@review_good",
                "patterns": [
                    "cái nào cũng đẹp",
                    "cái nào cũng đẹp hết ý",
                    "cái tui bao đẹp luôn",
                    "cảm nhận hàng shop b m nhận hàng về rất hài lòng về sản phẩm ,  chất lượng phom dáng đẹp lắm luôn ạ",
                    "chào em ,  hôm nay đồng nghiệp chị mặc 1 cái váy mua bên em lúc livestreem giá 200 rất đẹp",
                    "chất đẹp lắm",
                    "chất giống vải nâu lần đầu đẹp da man .  dầy dặn",
                    "lần đầu order đồ bên shop đẹp dã man luôn ạ . ",
                    "lần đầu tiên mua hàng bên em nhưng chị rất là hài lòng",
                    "chất ok lắm ạ"
                ]
            },
            {
                "tag": "User@review_bad",
                "patterns": [
                    "bên shop gọi chốt đơn rồi mà mấy ngày e chưa nhận được hàng luôn ạ",
                    "bên shop mình giao hàng lâu quá ạ .  ở thành phố hồ chí minh mà đặt 1 tuần chưa có hàng luôn",
                    "bị hơi dơ .  để c về giặt thử ra không",
                    "bị hư dây kéo",
                    "bị lem",
                    "bị lệch cai cổ",
                    "bị lỗi áo nha",
                    "bị rách phần nách tay",
                    "bốc mùi ẩm kinh khủng",
                    "bữa giờ chị nhận hàng nhà em sao mà rách rồi thiếu đồ buồn quá"
                ]
            },
            {
                "tag": "User@need_advice",
                "patterns": [
                    "m59 nặng 55kg mặc size gì ạ",
                    "50 kí cao 1m 55 mặt size nhiêu ạ",
                    "e cao 1m60 cao 54kg mặc size nào chị",
                    "quần này thường đi với áo kiểu nào vậy shop?",
                    "trời nóng mình nên mặc mẫu nào ha shop",
                    "mình cao 1m64 nặng 55kg thì mặc size nào ạ",
                    "mình dáng gầy shop có bán món nào phù hợp với mình không",
                    "anh mới được tặng áo polo, cho anh hỏi có quần nào cửa hàng có mà phù hợp với áo polo không ?",
                    "chị thích dạng áo sơ mi sọc, bên em có sản phẩm nào phù hợp không ?",
                    "mình cần tư vấn set đồ cho tiệc họp lớp"
                ]
            },
            {
                "tag": "User@wrong_information",
                "patterns": [
                    "e dat cai quan ,  tờ giay con ra bieu nhu vay ma nhét vo cai áo ,  e k hieu luôn á",
                    "giao hàng thiếu đồ vậy shop",
                    "gửi nhầm mẫu nha shop",
                    "shop gửi nhầm mãu cho mình rồi ,  mình đặt đầm nhung ở trên 245k nhung hôm nay shop lại gửi mẫu này cho mình",
                    "cho chị sửa tên lại là Trần Liễu",
                    "giao khác mẫu nè shop oi",
                    "lần trước chị gửi nhầm địa chỉ nên đồ của e bị lạc í c",
                    "tuần này chị không ở nhà. em gửi sang cho chị ở địa chỉ mới số 100 .  trần đại nghĩa .  phường tân tạo a .  bình tân .  thành phố hồ chí minh",
                    "mình nặng 52kg nha chứ không phải như nãy nói"
                ]
            },
            {
                "tag": "User@wrong_phone_number",
                "patterns": [
                    "sai số điện thoại á em",
                    "nhầm sđt",
                    "sai sđt",
                    "sđt sai r em",
                    "số điện thoại chị nhập sai á em",
                    "sđt bị sai r",
                    "điện thoại chị nhập sai r",
                    "nãy chị đặt sai số điện thoại",
                    "về số điện thoại chị nhập nhầm r em ơi ",
                    "sđt em nhập lộn r",
                    "ý mình sai sđt rồi",
                    "ý nhầm sđt rồi",
                    "ý nhầm sđt r",
                    "mình nhầm sđt mất r",
                    "ý lộn sđt rồi em"
                ]
            },
            {
                "tag": "User@wrong_address",
                "patterns": [
                    "sai địa chỉ rồi em ơi",
                    "nhầm địa chỉ",
                    "sai địa chỉ",
                    "số nhà sai r em",
                    "số nhà chị nhập sai á em",
                    "địa chỉ nhà bị sai r",
                    "nơi nhận chị nhập sai r",
                    "nãy chị đặt sai số địa chỉ",
                    "về nơi ở chị nhập nhầm r em ơi ",
                    "vị trí em nhập lộn r",
                    "ý mình sai địa điểm rồi",
                    "ý nhầm nơi chốn rồi",
                    "ý nhầm địa chỉ r",
                    "ý lộn địa chỉ rồi"
                ]
            },
            {
                "tag": "User@about_phone_number",
                "patterns": [
                    "số điện thoại á em",
                    "số điện thoại",
                    "sđt",
                    "sđt á em"
                ]
            },
            {
                "tag": "User@update_phone_number",
                "patterns": [
                    "số điện thoại 0357772221 nha em",
                    "sđt a là 0372221112 á em",
                    "0372221112 nha em",
                    "ý lộn sđt a là 0965554444",
                    "ý nhầm rồi số điện thoại chị là 0372221112",
                    "ý nhầm rồi sđt chị là 0372221112",
                    "0375182222"
                ]
            },
            {
                "tag": "User@update_address",
                "patterns": [
                    "địa chỉ mình là Tân Bình nha",
                    "mình ở quận Tân Bình nha",
                    "q Tân Bình á",
                    "quận tân phú nha em",
                    "lộn rồi. quận tân phú nha em",
                    "tân Bình nha em",
                    "tân phú nha em",
                    "cập nhật địa chỉ 236 lê trọng tấn quận tân phú",
                    "đổi địa chỉ thành nhận hàng thành 236 lê trọng tấn quận tân phú nha",
                    "à 226 tân kỳ tân quý tây thạnh tân phú nha",
                    "à 226 tân kì tân quý tây thạnh tân phú nha",
                    "anh ở Tân Phú nha",
                    "à mình ở số 15 Đường Lê Trọng Tấn Quận Tân Phú Thành phố Hồ Chí Minh",
                    "à anh ở Tân Bình nha",
                    "địa chỉ anh là Quận Tân Phú Thành phố Hồ Chí Minh .",
                    "tân Bình nha em",
                    "tân phú nha em",
                    "quận Tân Phú nha .",
                    "anh ở quận Tân Phú nha ."
                ]
            },
            {
                "tag": "User@update_time",
                "patterns": [
                    "chiều nay á",
                    "ngày mai nha ad",
                    "ngày 9/9 ạ",
                    "tầm 5h chiều mai á",
                    "cuối tuần này được không ad",
                    "ngày kia ạ",
                    "thứ sáu tuần này nha",
                    "ngày 25 á shop",
                    "ngày 5/9/2022",
                    "ngày 10 tháng sau ạ"
                ]
            },
            {
                "tag": "User@about_address",
                "patterns": [
                    "địa chỉ á em",
                    "địa chỉ",
                    "về địa chỉ",
                    "số nhà á em",
                    "số nhà",
                    "địa chỉ nhà",
                    "địa điểm ấy",
                    "nơi chốn"
                ]
            },
            {
                "tag": "User@cancel_order",
                "patterns": [
                    "Mình chỉ muốn lấy áo màu hồng thôi nên cho mình hủy đơn",
                    "sản phẩm giao chậm quá, mình muốn hủy đơn",
                    "shop nói sai với ban đầu tư vấn, tôi muốn hủy đơn",
                    "shop giao chậm hơn thời gian thông báo nên tôi muốn hủy đơn",
                    "nhân viên giao hàng thái độ bất lịch sự quá, tôi muốn hủy đơn",
                    "tôi nhắn tin rất nhiều nhưng shop không trả lời, tôi muốn hủy đơn",
                    "1 tuần hơn rồi mà vẫn chưa bắt đầu vận chuyển, tôi muốn hủy đơn",
                    "tôi đã đặt hàng nhưng thái độ bạn tư vấn thật bất lịch sự, tôi muốn hủy đơn",
                    "nếu shop hết mẫu này rồi thì cho tôi hủy đơn nhé",
                    "hết quà tặng rồi thì cho tôi hủy đơn nhé",
                    "làm ăn kiểu gì mà không ai trả lời tin nhắn hết vậy, tôi muốn hủy đơn",
                    "anh muốn hủy đơn á em",
                    "a hủy đơn á em",
                    "hủy đơn",
                    "hủy đơn giúp mình nha",
                    "hủy giùm đơn hàng nhé",
                    "à mình hủy đơn nha",
                    "mình không muốn mua nữa, hủy nha"
                ]
            },
            {
                "tag": "User@rollback_buy",
                "patterns": [
                    "cho em trả hàng lỗi lấy mẫu 2 được không ạ",
                    "cho m đổi trả được không",
                    "còn không co e gửi lại shop đổi lại dùm e ạ",
                    "còn không co em gửi lại shop đổi lại dùm em ạ",
                    "còn nếu shop con set áo vét thì đổi lại cho e cùng mẫu đó luôn cho dễ cũng được e cảm ơn shop",
                    "dạ vậy shop đổi giúp e nhé cảm ơn shop ạ",
                    "đổi cho mình bộ này vì mình đi tiệc",
                    "đổi cho mình đúng bộ đặt",
                    "shop cho em đổi cái này em bù tiền ship ạ",
                    "shop giúp e đổi lại set khác với ạ",
                    "shop ơi shop đổi cho e áo màu da lấy màu đỏ nha shop"
                ]
            },
            {
                "tag": "User@yes",
                "patterns": [
                    "ừ đúng nó r á",
                    "uhm okie em",
                    "uhm em",
                    "ừ em",
                    "ừ e",
                    "ừ okie em",
                    "chốt rồi",
                    "đúng mà em",
                    "có rồi nè",
                    "có bé",
                    "à đúng rồi",
                    "da rồi chị",
                    "em cho rồi",
                    "có đơn rồi",
                    "rùi em",
                    "lấy ok",
                    "được",
                    "okie",
                    "oke",
                    "được đấy nhỉ",
                    "đồng ý",
                    "đòng ý luôn",
                    "được luôn",
                    "chấp nhận",
                    "chấp thuận",
                    "chấp nhận luôn",
                    "chấp thuận luôn",
                    "ok",
                    "ok nha",
                    "ok nhé",
                    "okie luôn"
                ]
            },
            {
                "tag": "User@no",
                "patterns": [
                    "k chị ạ",
                    "k e nha",
                    "k anh",
                    "thôi không cần",
                    "dạ k c ơi",
                    "k phải",
                    "k cung",
                    "da khong",
                    "k xem được",
                    "không vừa nha",
                    "k",
                    "không",
                    "hok",
                    "kg",
                    "không được đâu nha",
                    "thôi",
                    "à không em",
                    "à k e",
                    "à kog em",
                    "à hog em",
                    "không được",
                    "nhiêu đó thôi em",
                    "không phải",
                    "không đúng",
                    "k đúng"
                ]
            },
            {
                "tag": "User@thanks",
                "patterns": [
                    "em cảm ơn ạ",
                    "cám ơn em",
                    "thanks shop ạ",
                    "thanks shop",
                    "ok thanks em",
                    "thanks c",
                    "em thanks ạ",
                    "em cám ơn ạ",
                    "c cam on e",
                    "cảm ơn c ạ"
                ]
            },
            {
                "tag": "User@wrong",
                "patterns": [
                    "sai r",
                    "sai rồi",
                    "nhầm",
                    "lộn",
                    "nãy mình nhầm",
                    "sai mất rồi",
                    "thôi rồi lượm ơi",
                    "thôi rồi",
                    "ý sai r",
                    "ý không phải",
                    "ý không đúng",
                    "ý ko phải",
                    "ý kog đúng",
                    "í k phải",
                    "không phải rồi",
                    "ko phải r",
                    "không đúng r"
                ]
            },
            {
                "tag": "User@hello",
                "patterns": [
                    "xin chào",
                    "chào",
                    "chào shop",
                    "chào em",
                    "hello",
                    "hi em ",
                    "hi",
                    "chào bạn nè",
                    "hello shop"
                ]
            },
            {
                "tag": "User@wrong_name",
                "patterns": [
                    "mình nhập sai tên rồi",
                    "mình sai tên mất r",
                    "sai tên r",
                    "lộn tên r em ây",
                    "tên sai mất r"
                ]
            },
            {
                "tag": "User@wrong_gender",
                "patterns": [
                    "mình nhập sai giới tính r rồi",
                    "lộn giới tính rồi",
                    "giới tính sai r"
                ]
            },
            {
                "tag": "User@update_gender",
                "patterns": [
                    "gọi mình là anh nha",
                    "mình là nam",
                    "tôi là con trai",
                    "t là đàn ông",
                    "t là nam",
                    "đàn ông nha má",
                    "trai nha nha",
                    "con trai á nha",
                    "đúng con trai r",
                    "gọi mình là chị nha",
                    "mình là nữ á",
                    "tôi là con gái",
                    "t là đàn bà",
                    "t là nữ",
                    "đàn bà nha má",
                    "đàn bà nha ông kia",
                    "nữ nha nha",
                    "con gái á nha",
                    "t là nam nha",
                    "t là nữ nha",
                    "đúng con gái r á",
                    "nam",
                    "Nam"
                ]
            },
            {
                "tag": "User@update_name",
                "patterns": [
                    "mình tên Nguyên nha",
                    "t tên Nguyên ấy",
                    "tên a là Phạm Quốc Nguyên nha",
                    "à mình là Nguyên á nha",
                    "Quốc Nguyên",
                    "Quốc Nguyên nha em"
                ]
            },
            {
                "tag": "User@any_thing_fine",
                "patterns": [
                    "sao cũng được",
                    "tùy ý bạn nha",
                    "random đi em",
                    "theo ý em",
                    "theo ý bạn",
                    "m muốn sao tùy",
                    "thích chọn gì chọn",
                    "thích gọi gì cũng oke",
                    "sao cũng oke hết á",
                    "thích làm gì làm",
                    "m thích gì chọn đó đi",
                    "sao cũng dc hết á",
                    "tùy ý anh á",
                    "tùy ý m á",
                    "tùy ý bọn mày"
                ]
            },
            {
                "tag": "User@wrong_height",
                "patterns": [
                    "lộn chiều cao r em",
                    "sai chiều cao rồi em ơi",
                    "nhầm chiều cao",
                    "sai chiều cao",
                    "chiều cao sai r em",
                    "chiều cao chị nhập sai á em",
                    "chiều cao nhà bị sai r",
                    "chiều cao chị nhập sai r",
                    "nãy chị đặt sai số chiều cao",
                    "về chiều cao chị nhập nhầm r em ơi ",
                    "độ cao em nhập lộn r",
                    "ý mình sai chiều cao rồi",
                    "ý nhầm chiều cao rồi",
                    "ý nhầm chiều cao r"
                ]
            },
            {
                "tag": "User@wrong_weight",
                "patterns": [
                    "lộn cân nặng r em",
                    "sai cân nặng rồi em ơi",
                    "nhầm cân nặng",
                    "sai cân ",
                    "cân nặng sai r em",
                    "cân nặng chị nhập sai á em",
                    "cân nặng nhà bị sai r",
                    "cân nặng chị nhập sai r",
                    "nãy chị đặt sai số cân nặng",
                    "về cân nặng chị nhập nhầm r em ơi ",
                    "cân nặng em nhập lộn r",
                    "ý mình sai cân rồi",
                    "ý nhầm cân nặng rồi",
                    "ý nhầm cân r"
                ]
            },
            {
                "tag": "User@update_height",
                "patterns": [
                    "cao 1m2 á em",
                    "chị cao 1m2",
                    "chiều cao 1m2",
                    "anh cao m2",
                    "m2 á em",
                    "cao 120 cm nha em",
                    "chiều cao 1.2m",
                    "chiều cao chị 1.2",
                    "à nhầm chị cao 1m9 lận",
                    "ý lộn mình cao m7 á",
                    "ý lộn t cao m7 á",
                    "mình cao m7 á",
                    "mình cao m9 lận á",
                    "à nhầm mình cao 1m9 lận",
                    "à nhầm bạn cao 1m9 lận"
                ]
            },
            {
                "tag": "User@update_weight",
                "patterns": [
                    "60kg nha em",
                    "chị nặng 60kg",
                    "nặng 60 á",
                    "60 ký nha em",
                    "nặng 60k",
                    "nặng 60 kg",
                    "60kg",
                    "60kg luôn nha em",
                    "60 kg luôn nha em"
                ]
            },
            {
                "tag": "User@update_size",
                "patterns": [
                    "size L á em",
                    "chị mặc l nha",
                    "chị mặc m nha",
                    "L nha em",
                    "M á em",
                    "lấy chị size L nha em"
                ]
            },
            {
                "tag": "User@request_consultant",
                "patterns": [
                    "shop có sản phẩm nào không",
                    "có sản phẩm nào tốt tốt không",
                    "mình bán gì vậy",
                    "sản phẩm nào hot vậy shop",
                    "giới thiệu tí đi nào",
                    "mình không biết mua gì hết",
                    "shop đang có đồ nào đẹp không",
                    "có mẫu nào vậy em",
                    "có đầm nào không em",
                    "có quần nào không em",
                    "có áo nào không em",
                    "có mũ nào không em",
                    "có giỏ nào không em",
                    "có balo nào không em"
                ]
            },
            {
                "tag": "User@request_add_product_to_bill",
                "patterns": [
                    "thêm vào đơn cho a nha",
                    "thêm đầm vào đơn cho anh",
                    "bỏ vào giỏ hàng cho a nhé",
                    "thêm vô giỏ hàng",
                    "thêm vô đơn đi em",
                    "anh muốn thêm đầm đó vào giỏ hàng"
                ]
            },
            {
                "tag": "User@request_billing",
                "patterns": [
                    "lên đơn giúp a nha",
                    "lên đơn nha em",
                    "chốt đơn nha",
                    "đơn a nhiêu vậy em",
                    "em lên đơn mấy món a vừa mua nha",
                    "lên đơn nhan",
                    "lấy chị mẫu này nha",
                    "lấy anh món này nhé",
                    "lên đơn cho chị nha",
                    "lên đơn cho mình luôn nha",
                    "tính tiền cho a nha",
                    "tính tiền nha em",
                    "tính tiền cho anh đi nè",
                    "tính tiền luôn nha",
                    "tính liền a đi em",
                    "thôi tính tiền nhanh đi",
                    "tính tiền lẹ cho mình nha",
                    "tính tiền lẹ lên coi",
                    "lên đơn giùm cái",
                    "m lên đơn tính tiền nhanh lên coi"
                ]
            },
            {
                "tag": "User@request_unclear",
                "patterns": [
                    "à anh hỏi tí",
                    "à a hỏi này tí ",
                    "em ơi a hỏi này",
                    "a hỏi này nha",
                    "a có việc này muốn hỏi em",
                    "thắc mắc này em giải đáp giúp anh nha",
                    "a có vấn đề muốn hỏi",
                    "có điều này còn thắc mắc",
                    "a muốn biết 1 điều",
                    "a muốn biết một điều",
                    "a muốn làm rõ 1 việc",
                    "a muốn làm rõ một việc"
                ]
            },
            {
                "tag": "User@request_weather",
                "patterns": [
                    "thời tiết hôm nay như nào á?",
                    "cho tui hỏi tình hình thời tiết với",
                    "hôm nay thời tiết có tốt không?",
                    "anh muốn biết tình hình thời tiết tại Gia Lai",
                    "hôm nay thời tiết xấu hay tốt?",
                    "trời hôm nay ok không",
                    "thời tiết ở Đà Nẵng như thế nào",
                    "thời tiết như nào?",
                    "hôm nay thời tiết nhiều gió không",
                    "mình muốn biết tình hình thời tiết hôm nay",
                    "thời tiết ngày mai như thế nào ạ",
                    "thời tiết tháng tới tại Hà Nội như thế nào ạ",
                    "thành phố HCM hôm nay thời tiết thế nào á"
                ]
            },
            {
                "tag": "User@sad_status_sentences",
                "patterns": [
                    "tôi buồn quá",
                    "bùn quá à",
                    "hôm nay buồn ghê",
                    "tôi có chuyện không vui",
                    "có chuyện kia không vui",
                    "chuyện không vui",
                    "mắc dỗi ghê",
                    "quạu thiệt chứ",
                    "khó chịu thật sự",
                    "tôi chán quá",
                    "không có chuyện gì vui hết"
                ]
            },
            {
                "tag": "User@happy_status_sentences",
                "patterns": [
                    "tôi vui quá",
                    "vui thiệt chứ",
                    "hôm nay vui ghê",
                    "tôi có chuyện vui á",
                    "có chuyện kia vui lắm",
                    "mình hạnh phúc lắm",
                    "mình sướng hết cả người",
                    "tôi hài lòng",
                    "không có chuyện gì buồn hết"
                ]
            },
            {
                "tag": "User@normal_status_sentences",
                "patterns": [
                    "tôi bình thường",
                    "bình thường á",
                    "chả có chuyện gì",
                    "như mọi ngày",
                    "vẫn vậy",
                    "mọi thứ đều ổn",
                    "vẫn ổn",
                    "ổn à",
                    "không có gì đặc biết",
                    "như mọi hôm"
                ]
            },
            {
                "tag": "User@request_bill_info",
                "patterns": [
                    "đơn của anh thế nào rồi",
                    "đơn của chị đến chưa em",
                    "cho anh xin thông tin đơn hàng nhé",
                    "xem thông tin đơn hàng",
                    "đơn của mình xử lý đến đâu rồi",
                    "hàng của mình xử lý thế nào rồi đấy",
                    "em cho a biết tình hình đơn hàng nha",
                    "đơn giao ổn không em",
                    "hàng của anh giao được không em",
                    "cho a biết thông tin đơn của anh nhé",
                    "đơn hàng của a thế nào rồi em biết không ",
                    "đơn hàng của anh ",
                    "đơn hàng của a đến đâu r em",
                    "đơn của mình sao rồi"
                ]
            },
            {
                "tag": "User@request_cancel_bill_process",
                "patterns": [
                    "đơn của anh hủy được chưa em",
                    "đơn của mình hủy thành công chưa",
                    "hủy đơn rồi đúng không em",
                    "đơn anh hủy xử lý xong chưa em",
                    "đơn anh bỏ bên em xử lý thế nào rồi á "
                ]
            },
            {
                "tag": "User@request_number_of_bills",
                "patterns": [
                    "anh đã đặt nhiêu đơn rồi em",
                    "c có bao nhiêu đơn rồi vậy e",
                    "a có bao nhiêu đơn rồi vậy e",
                    "anh có mấy đơn rồi em"
                ]
            },
            {
                "tag": "User@request_weather_detail",
                "patterns": [
                    "hôm nay trời có mưa không ạ",
                    "hôm nay có mưa không ad",
                    "Hà Nội hôm nay mưa hay nắng á ad",
                    "ngày mai trời có nắng không á",
                    "tháng tới có mưa không ạ",
                    "tuần sau có mưa không ạ",
                    "chiều nay nắng hay mưa á",
                    "Gia Lai có mưa không ạ",
                    "Lâm Đồng hôm nay trời có nắng không",
                    "tuần tới có khả năng mưa không",
                    "ngày mốt k biết trời có mưa không ạ"
                ]
            },
            {
                "tag": "User@request_copy_bill",
                "patterns": [
                    "mình muốn đặt lại đơn lần trước",
                    "cho mình đặt lại cùng đơn hồi bữa nha",
                    "tôi muốn đặt đơn như lần liền kề",
                    "a muốn đặt lại đơn như trước",
                    "chị cần đặt lại đầm như trước",
                    "anh cần mua giày như hôm trước",
                    "em lấy anh giống lần trước nha"
                ]
            },
            {
                "tag": "User@inform_done_payment",
                "patterns": [
                    "anh chuyền khoản rồi á em",
                    "chuyển xong r em kiểm tra giúp a nha",
                    "chị vừa chuyển á em coi check giúp chị với",
                    "check tiền tài khoản nha chị mới chuyển r",
                    "chị chuyển rồi ấy. em kiểm tra giúp nha",
                    "tiền vừa đi rồi em kiểm tra giúp a nha",
                    "kiểm tra xem tiền tới chưa nha em",
                    "a chuyển r nha",
                    "chị chuyển r nha",
                    "c chuyển r nha"
                ]
            },
            {
                "tag": "User@request_order_guide",
                "patterns": [
                    "mình đặt hàng thế nào vậy em",
                    "làm sao để đặt hàng",
                    "có hướng dẫn đặt hàng ko em",
                    "cho a xin cái hướng dẫn đặt đơn với",
                    "làm sao đặt hàng cho nhanh em",
                    "anh muốn đặt hàng nhưng ko biết làm thế nào",
                    "làm thế nào đặt hàng nhỉ",
                    "mua như thế nào vậy em",
                    "hướng dẫn anh đặt hàng với"
                ]
            },
            {
                "tag": "User@request_order_watch_guide",
                "patterns": [
                    "làm sao theo dõi đơn hàng vậy",
                    "theo dõi đơn hàng thì làm sao",
                    "hướng dẫn a cách tracking đơn hàng nha",
                    "chỉ mình track đơn hàng",
                    "chỉ chị cách theo dõi đơn với",
                    "mô tả cho a cách theo dõi đơn",
                    "làm sao để biết được thông tin đơn hàng",
                    "muốn theo dõi đơn thì làm thế nào ta",
                    "em hướng dẫn a theo dõi đơn hàng nha"
                ]
            },
            {
                "tag": "User@request_change_policy",
                "patterns": [
                    "bên mình có cho đổi trả hàng không em",
                    "mình có đổi hàng được không",
                    "chính sách đổi trả hàng thế nào",
                    "anh muốn đổi hàng làm thế nào em",
                    "làm sao đổi trả vậy em",
                    "a không biết đổi trả hàng ntn mới được",
                    "chỉ chị cách đổi trả nhé",
                    "cho a hướng dẫn đổi trả nha",
                    "làm sao để đổi hàng cho a hướng dẫn với nha"
                ]
            },
            {
                "tag": "User@request_working_time",
                "patterns": [
                    "bên mình làm tới mấy h vậy ",
                    "bên em làm đến mấy giờ",
                    "thời gian làm việc thế nào",
                    "shop mở cửa đến mấy h",
                    "thời gian mở của ntn vậy em",
                    "bình thường mình làm tới mấy h vậy",
                    "có làm cuối tuần không em",
                    "cuối tuần shop có mở của không",
                    "cuối tuần anh sang được không em",
                    "chị sang lúc nào được em"
                ]
            },
            {
                "tag": "User@request_hotline",
                "patterns": [
                    "cho anh xin số điện thoại với",
                    "cho chị xin sđt nha",
                    "chị gọi đến số nào được em",
                    "a gọi đến đâu được v em",
                    "a muốn tư vấn cụ thể thì gọi đến số nào",
                    "liên hệ thế nào vậy",
                    "cho a hotline liên hệ nha",
                    "cho mình xin số hotline",
                    "cho mình xin sđt liên hệ nha",
                    "số đt nhiêu vậy để mình gọi cho dễ",
                    "ad gửi mình sđt với có gì mình gọi"
                ]
            },
            {
                "tag": "User@request_showroom_info",
                "patterns": [
                    "mình muốn xin hàng thì đến đâu",
                    "đến đâu xem hàng",
                    "mình có các địa chỉ nào vậy em",
                    "shop mình có ở quận 1 không",
                    "mình có chi nhánh ở quận Tân Phú không",
                    "mình có các chi nhánh nào",
                    "cho a xin cái địa chỉ",
                    "xin địa chỉ shop với",
                    "cung cấp thông tin địa chỉ showroom giúp nhé",
                    "mua ở đâu được em",
                    "anh muốn xem tận mắt thì đến đâu vậy em",
                    "anh muốn thấy sản phẩm tận mắt",
                    "anh muốn xem sản phẩm thì đến đâu vậy em",
                    "shop địa chỉ đâu v"
                ]
            },
            {
                "tag": "User@request_payment_policy",
                "patterns": [
                    "thanh toán thế nào em",
                    "anh chuyển khoản được ko",
                    "chuyển khoản được ko em",
                    "gửi qua bank nha em",
                    "cho a xin thông tin thanh toán nha",
                    "mình có thể thanh toán qua kênh nào nhỉ",
                    "a gửi tiền qua đâu được v em",
                    "anh chuyển khoản cho em nha",
                    "chuyển tiền qua bank nha em",
                    "có thanh toán momo được không em",
                    "anh chuyển techcombank được không",
                    "chị chuyển sacom được ko",
                    "vietinbank được ko em",
                    "thanh toán sao vậy em",
                    "thanh toán sao v em",
                    "thanh toán như thế nào"
                ]
            },
            {
                "tag": "User@request_discount",
                "patterns": [
                    "giảm giá được không em",
                    "có giảm giá không đấy",
                    "anh mua thì có giảm giá không",
                    "có chiết khẩu chút đỉnh nào không em",
                    "anh quen rồi có giảm tí nào ko thế",
                    "chị thường mua vậy có giảm không em",
                    "giảm cho chị xíu đi nha",
                    "làm ơn giảm cho mình tí đi",
                    "giảm tí đi mà",
                    "giá cáo thế giảm tí đi",
                    "mình thích lắm nhưng không có tiền. Giảm tí cho mình nha",
                    "hạ giá một chút nha em ơi",
                    "giảm giá cho mình khách quen mà",
                    "giảm giá cho anh xíu nhe em yêu",
                    "giảm tí đi mà mắc quá"
                ]
            },
            {
                "tag": "User@request_cancel_product",
                "patterns": [
                    "cho anh bỏ [ sản phẩm ] ra khỏi đơn nha",
                    "à cho mình bỏ [ sản phẩm ] khỏi đơn với shop",
                    "bỏ giúp mình túi ra khỏi đơn nha",
                    "mình không muốn đặt đầm nữa shop bỏ giúp mình món đó nhé",
                    "hủy giúp chị [ sản phẩm ] nha",
                    "hủy giúp mình [ sản phẩm ] với ad ",
                    "hủy sản phẩm [ sản phẩm ] giúp anh nha",
                    "cho mình hủy món này với shop",
                    "mình không đặt [ sản phẩm ] nữa nha"
                ]
            },
            {
                "tag": "User@reject_product",
                "patterns": [
                    "đây không phải sản phẩm mình quan tâm",
                    "đây k phải sp anh quan tâm",
                    "đây k phải sản phẩm chị quan tâm",
                    "đây không phải sản phẩm mình quan tâm",
                    "kp sản phẩm này r",
                    "kp sp này",
                    "k phải cái này"
                ]
            }
        ],
        "threshold": 0.75
    }
}


for item in data["data"]["intents"]:
    print(len(item["patterns"]), len(set(item["patterns"])))
