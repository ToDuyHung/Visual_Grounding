import json
import string

data = json.load(open("./product_information.json", "r", encoding="utf8"))
words = set()

for item in data:
    words = words.union(item["attributes"])
    for attr in item["attributes"]:
        words = words.union(item["attributes"][attr])

new_words = set(list(string.punctuation + "₫#"))
for word in words:
    word = word.lower().replace("_", " ")
    for c in string.punctuation + "₫#":
        word = word.replace(c, " ")
    done = False
    while not done:
        done = True
        for i in range(len(word)):
            if i < len(word) - 1 and word[i] in string.digits and word[i+1] not in string.digits + " ":
                word = word[:i + 1] + " " + word[i + 1:]
                done = False
                break

    new_words = new_words.union(set(word.split()))

print(list(new_words))

