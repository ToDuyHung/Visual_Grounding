import requests
import json
import os
from tqdm import tqdm


# url = "http://172.28.0.23:35432/api/file/upload-file-local"
url = "https://files.tmtco.dev/api/v2/Media/upload-files"

for file_name in tqdm(os.listdir("C:/nguyenpq/workspace/ChatBot/Common/TMTChatbot/StateController/scripts/demo/image")):
    files = [
        ('FileContent',
         (f'demo_shop_{file_name.replace("_", "-")}', open(f'C:/nguyenpq/workspace/ChatBot/Common/TMTChatbot/StateController/scripts/demo/image/{file_name}', 'rb').read(), 'image/jpeg'))
    ]

    response = requests.request("POST", url, files=files, headers={
        "Content-Type": "multipart/form-data",
        "accept": "text/plain",
        "App-Id": "tpos.vn",
        "App-Secret": "cjgMuAM3f755NqnVs4WE9CvkLyliKfX8",
        "App-Folder": "tpos"
    })

    print(response.text)
    break


for file_name in tqdm(os.listdir("C:/nguyenpq/workspace/ChatBot/Common/TMTChatbot/StateController/scripts/demo/image")):
    headers = {
        'accept': 'text/plain',
        'App-Id': 'tpos.vn',
        'App-Secret': 'cjgMuAM3f755NqnVs4WE9CvkLyliKfX8',
        'App-Folder': 'tpos'
    }

    files = {
        'Files': (f'demo_shop_{file_name}-{file_name.replace("_", "-")}',
                  open(os.path.join("C:/nguyenpq/workspace/ChatBot/Common/TMTChatbot/StateController/scripts/demo/image", file_name), 'rb').read(), 'image/jpeg'),
        'FolderPath': (None, 'team-ai'),
        'Overwrite': (None, 'true'),
        'Tenant': (None, ''),
    }

    result = requests.post('https://files.tmtco.dev/api/v2/Media/upload-files', headers=headers, files=files)

    result = result.json()
    break