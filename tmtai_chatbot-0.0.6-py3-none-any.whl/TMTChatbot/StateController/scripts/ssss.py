import torch
from transformers import AutoModel, AutoTokenizer
from transformers import MBartForConditionalGeneration

tokenizer = AutoTokenizer.from_pretrained("vinai/bartpho-syllable")
bartpho = MBartForConditionalGeneration.from_pretrained("vinai/bartpho-syllable")

TXT = "Chúng tôi là <mask> nghiên cứu viên."
input_ids = tokenizer([TXT], return_tensors="pt")
# logits = bartpho(input_ids).logits
# masked_index = (input_ids[0] == tokenizer.mask_token_id).nonzero().item()
# probs = logits[0, masked_index].softmax(dim=0)
# values, predictions = probs.topk(5)
# print(tokenizer.decode(predictions).split())

outputs = bartpho.generate(**input_ids, num_beams=5, max_length=256)
print(outputs)
print(tokenizer.decode([outputs]))