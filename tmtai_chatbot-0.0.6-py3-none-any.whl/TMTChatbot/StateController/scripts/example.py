from TMTChatbot.Common.utils.logging_utils import setup_logging
from TMTChatbot.StateController.config import ConversationConfig
from TMTChatbot.Schema.objects.conversation import Conversation, State, Message
from TMTChatbot.Schema.objects.common.data_model import BaseDataModel
from TMTChatbot.StateController.base_state_processor import BaseStateProcessor

if __name__ == "__main__":
    _config = ConversationConfig(intent_url="http://172.29.13.24:20221", graph_qa_url="http://172.29.13.24:20224",
                                 ner_url="http://172.29.13.24:20220",
                                 doc_qa_url="http://172.29.13.24:20227", mongo_host="172.29.13.24",
                                 node_search_url="http://172.29.13.24:20223",
                                 mongo_port=20253)
    setup_logging(logging_folder="logs", log_name="example.log")
    state_controller = BaseStateProcessor(_config)
    conversation_data = {
        "_id": "1",
        "class": "Conversation",
        "storage_id": "test"
    }
    _conversation: Conversation = Conversation.from_json(conversation_data, storage=state_controller.storage)
    print(_conversation.current_state.state_action_config)
    # _conversation.save()

    # state: State = _conversation.current_state
    # if state is not None:
    #     state.add_message(Message(message="cao 1m2", storage=state_controller.storage))
    #     # state.add_message(Message(message="giày sneaker giá nhiêu vậy", storage=state_controller.storage))
    #     # state.add_message(Message(message="xin chào", storage=state_controller.storage))
    # else:
    #     _conversation.new_state_with_message(message=Message("đầm lovito màu gì ấy", storage=state_controller.storage))
    #
    # _conversation.save()
    # print(_conversation.json)
    #
    _conversation.drop_state()
    _conversation.save()
    _conversation.new_state_with_message(Message(message="Xin chào", storage=state_controller.storage),
                                         state_action_config_id="consultant_size")
    print(_conversation.json)
    # state_controller.information_extractor.node_search_service(_conversation)
    _conversation.user.drop_all_attributes()
    _conversation.save()
    conversation_json = _conversation.json
    while True:
        _conversation = Conversation.from_json(conversation_json, storage=state_controller.storage)
        _conversation: Conversation = state_controller.process(_conversation, save=True)
        print("Response: ", _conversation.current_state.response.message)
        _conversation.save()
        message = input("Message:")
        _conversation.current_state.add_message(Message(message=message, storage=state_controller.storage))
        _conversation.save()
        conversation_json = _conversation.json
        # _conversation: Conversation = state_controller.process(_conversation)

        # _conversation.current_state.add_message(Message(message="0357172238, quận Tân Phú", storage=state_controller.storage))
        # _conversation.save()
        # output: Conversation = state_controller.process(_conversation)
        # print(output.current_state.message.message)
        # print(output.current_state.response.message)
