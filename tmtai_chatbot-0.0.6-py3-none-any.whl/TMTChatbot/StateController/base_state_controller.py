from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton
from TMTChatbot.StateController.config.config import Config
from TMTChatbot.StateController.services.information_extractor import BaseInformationExtractor
from TMTChatbot.StateController.base_state_processor import BaseStateProcessor
from TMTChatbot.Schema.objects.conversation.conversation import Conversation, Message, Response
from TMTChatbot.Common.storage.mongo_client import MongoConnector
from TMTChatbot.StateController.services.bot_intent import BotIntent


class BaseStateController(BaseServiceSingleton):
    def __init__(self, config: Config = None):
        super(BaseStateController, self).__init__(config=config)
        self.state_processor = BaseStateProcessor(config=config)
        self.information_extractor = BaseInformationExtractor(config=config)
        self.bot_intent_extractor = BotIntent(config=config)
        self.storage = MongoConnector(config=config)

    @staticmethod
    def next_state(conversation: Conversation):
        need_response_states = []
        current_action = conversation.current_action
        while not conversation.current_state.done:
            if conversation.current_action != current_action:
                conversation.current_action.refresh()
                need_response_states.append(conversation.current_state)
            conversation.next_state()
        return need_response_states

    def process(self, conversation: Conversation) -> Response:
        self.information_extractor.message_information_extraction(conversation)
        self.bot_intent_extractor.extract_global_intents(conversation)

        conversation.get_state_by_entry_point()
        conversation.current_state.add_message(message=conversation.pending_message)
        conversation.drop_pending_message()
        conversation = self.state_processor(conversation)
        response = conversation.current_state.response

        pre_responses = []
        current_state = conversation.current_state
        count = 3
        while conversation.current_state is not None and conversation.current_state.done and count > 0:
            conversation.next_state()
            count -= 1
            if conversation.current_state != current_state:
                conversation = self.state_processor.pass_response(conversation)
                pre_responses.append(conversation.current_state.response)
            else:
                break
            current_state = conversation.current_state

        for pre_response in pre_responses:
            response.join(pre_response, delimiter=self.config.response_delimiter)
        return response

    def refresh_conversation(self, message: Message):
        conversation = Conversation.from_user_shop_id(user_id=message.user_id, shop_id=message.shop_id,
                                                      storage=self.storage, storage_id=message.storage_id)
        conversation.user.drop_all_attributes()
        if conversation.data.bill is not None:
            conversation.data.bill.delete(force=True)
        if conversation.data.weather is not None:
            conversation.data.weather.delete(force=True)
        conversation.data.remove_all_nodes()
        conversation.data.init_bill()
        conversation.data.init_weather()
        while conversation.current_state is not None:
            conversation.drop_state()

        while conversation.pending_message is not None:
            conversation.drop_pending_message()

        conversation.script_config = None
        conversation.save(force=True)

    def __call__(self, message: Message, script_config=None) -> Response:
        if (message.message is None or message.message == "") and (message.urls is None or len(message.urls) == 0) and \
                (message.base64_img is None or len(message.base64_img) == 0):
            return Response(message="", storage_id=message.storage_id, user_id=message.user_id,
                            shop_id=message.shop_id)
        import time
        s = time.time()

        conversation = Conversation.from_user_shop_id(user_id=message.user_id, shop_id=message.shop_id,
                                                      storage=self.storage, storage_id=message.storage_id,
                                                      script_config=script_config)
        print("---LOAD conv", time.time() - s)
        s = time.time()
        conversation.add_pending_message(message)
        conversation.save()
        all_response = Response(message="", storage_id=message.storage_id, user_id=message.user_id,
                                shop_id=message.shop_id)
        print("---save conv pending", time.time() - s)
        s = time.time()
        while len(conversation.pending_messages) > 0:
            response = self.process(conversation)
            all_response.join(response, delimiter=self.config.response_delimiter)
            conversation.save()
            print("---processing", time.time() - s)
            s = time.time()
        all_response.message = self.state_processor.post_process(all_response.message,
                                                                 delimiter=self.config.response_delimiter)
        return all_response


if __name__ == "__main__":
    from TMTChatbot.StateController.config import ConversationConfig

    _config = ConversationConfig(intent_url="http://172.29.13.24:20221", graph_qa_url="http://172.29.13.24:20224",
                                 ner_url="http://172.29.13.24:20220",
                                 doc_qa_url="http://172.29.13.24:20227", mongo_host="172.29.13.24",
                                 node_search_url="http://172.29.13.24:20223",
                                 mongo_port=20253)
    controller = BaseStateController(config=_config)
    _message = Message.from_json({
        "name": "Message_f3a7cbbe-dc76-5173-b265-7282bdcb234f",
        "message": "Xin chào",
        "created_time": 1660202038,
        "storage_id": "test",
        "hashed": "6807ae66a5b30f416f3ecf0da78e4acc",
        "_id": "f3a7cbbe-dc76-5173-b265-7282bdcb234f",
        "class": "Message",
        "user_id": "nguyenpq",
        "shop_id": "f853c5c9-b7a5-5220-82a1-1c1a94777e4e"
    }, storage=controller.storage)
    controller(message=_message)
