from TMTChatbot.Common.common_keys import *


class BaseSchemaConfig:
    def __init__(self, data=None, validate=True):
        if validate:
            self.validate_data(data)
        self.data = data

    def class_name(self):
        return self.data[CLASS]

    @property
    def parent_class(self):
        return self.data.get(PARENT_CLASS)

    @property
    def required_attributes(self):
        return self.data.get(REQUIRED_ATTRIBUTES, [])

    @property
    def attributes(self):
        return self.data.get(ATTRIBUTES, [])

    @property
    def variant_attributes(self):
        return self.data.get(VARIANT_ATTRIBUTES, [])

    @property
    def all_attributes(self):
        return list(set(self.attributes + self.required_attributes + self.variant_attributes))

    @staticmethod
    def from_json(data):
        return BaseSchemaConfig(data)

    @property
    def json(self):
        return self.data

    @staticmethod
    def validate_data(data):
        for attribute in [CLASS, REQUIRED_ATTRIBUTES, VARIANT_ATTRIBUTES]:
            if attribute not in data:
                raise ValueError(f"[{attribute}] key must exist")

        if not set(data[VARIANT_ATTRIBUTES]).issubset(data[REQUIRED_ATTRIBUTES]):
            raise ValueError(f"Variants attributes must be a subset of required attributes")
