from TMTChatbot.Schema.objects.lang.phrase import Phrase
from TMTChatbot.Schema.objects.lang.word import Word
from TMTChatbot.Schema.objects.lang.sentence import Sentence
