
class PhraseMask:
    SRC_MASK = "AA"
    DST_MASK = "BB"
