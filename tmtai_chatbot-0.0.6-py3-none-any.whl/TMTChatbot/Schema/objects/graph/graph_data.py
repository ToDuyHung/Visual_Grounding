import string
import sys
from abc import ABC

import numpy as np
from typing import List, Dict, Union, Set
from datetime import datetime
import random

from TMTChatbot.Common.constants import *
from TMTChatbot.Common.common_keys import *
from TMTChatbot.Common.common_phrases import INTENSIVE_WORDS
from TMTChatbot.Schema.common.graph_types import DataType, NodeTypes, RelationTypes, PhraseMask
from TMTChatbot.Schema.common.product_types import BillStatus, ProductStatus, PaymentStatus, BankVerificationMethod
from TMTChatbot.Common.utils.data_utils import check_data_type
from TMTChatbot.Schema.objects.base_object import BaseObject


class Node(BaseObject):
    def __init__(self, storage_id: str, index, name: str, storage=None, aliases=None, parent_class=None, schema=None,
                 score=0, update_func=None, schema_required=None, mentioned_times: List[int] = None,
                 image_urls: List[str] = None, image_features: List = None, **kwargs):
        super(Node, self).__init__(_id=index, storage=storage, schema=schema, parent_class=parent_class,
                                   schema_required=schema_required, storage_id=storage_id, **kwargs)
        name, data_type = check_data_type(name)
        self.name = name if name is None else str(name)
        self.data_type = data_type
        self.in_relations: Dict[str, Relation] = {}
        self.out_relations: Dict[str, Relation] = {}
        self.attribute_relations: Dict[str, Relation] = {}
        self.attribute_relations_mapping: Dict[str, List[str]] = {}
        self.in_relations_score: Dict[Relation, float] = {}
        self.out_relations_score: Dict[Relation, float] = {}
        self.attribute_relations_score: Dict[Relation, float] = {}
        self.type = NodeTypes.ENTITY
        self._aliases = aliases if aliases is not None else []
        self.init_empty_attributes()

        self._score = score
        self.phrases = set()
        self.update_func = update_func
        self.updated = False
        self._energy = 0
        self._mentioned_times = mentioned_times if mentioned_times is not None else []
        self.image_urls = image_urls if image_urls is not None else []
        self.image_features = image_features if image_features is not None else []
        self.alias = None

    def pre_process_name(self, intensive_words: Union[List[str], Set[str]] = None):
        if intensive_words is None:
            intensive_words = INTENSIVE_WORDS
        name = f" {self.name} ".lower()
        for c in string.punctuation:
            name = name.replace(c, f" {c} ")
        name_word_set = set(name.split())
        for word in name_word_set.intersection(intensive_words):
            name = name.replace(f" {word} ", " ")
        while "  " in name:
            name = name.replace("  ", " ")
        return name.strip()

    @classmethod
    def skip_fields(cls):
        return [NODE_IMAGE_FEATURES]

    @property
    def mentioned_times(self):
        return self._mentioned_times

    def get_mentioned_time(self, step=-1):
        if self._mentioned_times is None or len(self._mentioned_times) == 0 or -step - 1 >= len(self._mentioned_times):
            return 0
        return self._mentioned_times[step]

    def set_mentioned_time(self, _mentioned_time):
        self._mentioned_times.append(_mentioned_time)
        self._mentioned_times = self._mentioned_times[-5:]

    def init_empty_attributes(self):
        for attribute_name in self.schema.all_attributes:
            self.set_attr(attr=attribute_name, value=None, force=False)

    @property
    def relations(self):
        return list(self.in_relations.values()) + list(self.out_relations.values())

    @property
    def all_out_relations(self):
        return list(self.out_relations.values()) + list(self.attribute_relations.values())

    @property
    def all_relations(self):
        return list(self.in_relations.values()) + list(self.out_relations.values()) + \
               list(self.attribute_relations.values())

    def add_in_relation(self, relation, score=0):
        self.in_relations_score[relation] = score

    def add_out_relation(self, relation, score=0):
        if relation in self.out_relations:
            self.out_relations_score[relation] = score
        else:
            self.attribute_relations_score[relation] = score

    @property
    def aliases(self):
        output = list(item for item in {*self._aliases, self.name, self.class_name().lower(), self.parent_class}
                      if item is not None)
        if self.alias is not None:
            output.append(self.alias)
        return output

    @aliases.setter
    def aliases(self, _aliases):
        self._aliases = list(set(self._aliases + _aliases))

    @property
    def attribute_words(self):
        attrs = set()
        for r in self.attribute_relations.values():
            attrs = attrs.union(set(r.words))
        return attrs

    @property
    def json_attributes(self):
        output = dict()
        for attribute_name in self.schema.all_attributes:
            output[attribute_name] = []
        for r in self.attribute_relations.values():
            if r.name not in output:
                output[r.name] = []
            if r.dst_node.name is not None:
                output[r.name].append([r.dst_node.name, r.mentioned_time])
        for relation_name in output:
            if len(output[relation_name]) > 0:
                output[relation_name].sort(key=lambda item: item[1])
            output[relation_name] = [item[0] for item in output[relation_name]]
        return output

    @property
    def energy(self):
        return self._energy

    def add_energy(self, _energy):
        if self._energy == 0:
            self._energy = 1
            out_relations = list(self.all_out_relations)
            out_scores = np.array([self.out_relations_score[relation]
                                   if relation in self.out_relations else self.attribute_relations_score[relation]
                                   for relation in out_relations])
            out_scores[out_scores < EPSILON] = 0
            out_scores = out_scores / max([np.sum(out_scores), 1e-9])
            for out_relation, out_score in zip(out_relations, out_scores):
                if out_score >= EPSILON:
                    out_relation.dst_node.add_energy(1)

            in_relations = list(self.in_relations.values())
            in_scores = np.array([self.in_relations_score[relation] for relation in in_relations])
            in_scores[in_scores < EPSILON] = 0
            in_scores = in_scores / max([np.sum(in_scores), 1e-9])
            for in_relation, in_score in zip(in_relations, in_scores):
                if in_score >= EPSILON:
                    in_relation.src_node.add_energy(1)

    def free_energy(self):
        if self._energy != 0:
            self._energy = 0
            for relation in list(self.out_relations.values()) + list(self.in_relations.values()):
                relation.dst_node.free_energy()
                relation.src_node.free_energy()

    @property
    def score(self):
        return self._score

    @score.setter
    def score(self, _score):
        self._score = max([_score, self._score])

    @property
    def is_mapped(self):
        return len(self.phrases) > 0

    def add_phrase(self, phrase):
        self.phrases.add(phrase)

    def remove_phrase(self, phrase):
        if phrase in self.phrases:
            self.phrases.remove(phrase)

    def update_neighbours(self):
        if self.update_func is not None:
            self.update_func(self)

    def get_attr(self, attr):
        attr_relation_ids = self.attribute_relations_mapping.get(attr, [])
        attr_relations = [self.attribute_relations[attr_relation_id] for attr_relation_id in attr_relation_ids]
        if len(attr_relations) > 0:
            attr_relations.sort(key=lambda rel: rel.mentioned_time)
            output = [attr_relation.dst_node.name for attr_relation in attr_relations]
            output = [item for item in output if item is not None]
            return output
            # if len(output) == 1:
            #     return output[0]
            # else:
            #     return ", ".join(output)

    def set_attr(self, attr: str, value: str = None, force=True):
        """
        Create (or modify if existed) a new attribute for the current object node
        :param force: if relation is force replace in this object's out_relations else add if not exists
        :param attr: attribute name
        :param value: value of this attribute
        :return: None
        """
        is_required = attr in self.schema.required_attributes
        attr_node = self.get_attr(attr)
        if attr_node is None or force:
            attr_node = ValueNode(index=self.generate_hash(f"{self.id}{attr}{value}"), prop_name=attr, name=value,
                                  storage_id=self.storage_id)
            if is_required:
                attr_relation = RequiredAttributeRelation(src_node=self, dst_node=attr_node, name=attr,
                                                          storage=self.storage, storage_id=self.storage_id)
            else:
                attr_relation = AttributeRelation(src_node=self, dst_node=attr_node, name=attr, storage=self.storage,
                                                  storage_id=self.storage_id)

            if force or attr_relation.id not in self.attribute_relations:
                self.attribute_relations[attr_relation.id] = attr_relation
                self.attribute_relations_score[attr_relation] = 0
                if attr_relation.name not in self.attribute_relations_mapping:
                    self.attribute_relations_mapping[attr_relation.name] = []
                if attr_relation.id not in self.attribute_relations_mapping[attr_relation.name]:
                    self.attribute_relations_mapping[attr_relation.name].append(attr_relation.id)
                    remove_attr_ids = []
                    if len(self.attribute_relations_mapping[attr_relation.name]) > 1:
                        for attr_relation_id in self.attribute_relations_mapping[attr_relation.name]:
                            if self.attribute_relations[attr_relation_id].dst_node.name is None:
                                remove_attr_ids.append(attr_relation_id)
                        for attr_relation_id in remove_attr_ids:
                            relation = self.attribute_relations[attr_relation_id]
                            del self.attribute_relations[attr_relation_id]
                            del self.attribute_relations_score[relation]
                            self.attribute_relations_mapping[relation.name].remove(attr_relation_id)

    def drop_attr(self, attr):
        attr_relation_ids = self.attribute_relations_mapping.get(attr, [])
        for attr_relation_id in attr_relation_ids:
            relation = self.attribute_relations[attr_relation_id]
            del relation.dst_node
            del relation
            del self.attribute_relations[attr_relation_id]
        self.attribute_relations_mapping[attr] = []

    def drop_all_attributes(self):
        for attr_relation_id in list(self.attribute_relations):
            relation = self.attribute_relations[attr_relation_id]
            del relation.dst_node
            del relation
            del self.attribute_relations[attr_relation_id]
        for relation_name in self.attribute_relations_mapping:
            self.attribute_relations_mapping[relation_name] = []

    @property
    def missing_required_attributes(self) -> List[str]:
        output = {}
        for attribute_name in self.schema.required_attributes:
            output[attribute_name] = []
        for r in self.attribute_relations.values():
            if r.name not in output:
                continue
            if r.dst_node.name is not None:
                output[r.name].append([r.dst_node.name, r.mentioned_time])

        return [attribute_name for attribute_name in output if len(output[attribute_name]) == 0]

    def __repr__(self):
        return self.id

    # @property
    # def image_urls(self):
    #     output = [r.dst_node.image_url for r in self.attribute_relations.values()]
    #     output = [item for item in output if item is not None]
    #     return output
    #
    @property
    def image_url(self):
        if isinstance(self, ValueNode) and self.data_type == DataType.IMAGE_URL:
            return self.name

    @property
    def full_info(self):
        return self.name is not None

    def src_dst_relations(self, other, rel_type):
        joined_relations = set(self.out_relations).intersection(other.in_relations)
        joined_relations = [self.out_relations[r_id] for r_id in joined_relations]
        joined_relations = [item for item in joined_relations if item.name == rel_type]
        return joined_relations

    def remove_relation(self, relation):
        if relation.id in self.in_relations:
            del self.in_relations[relation]
        if relation.id in self.out_relations:
            del self.out_relations[relation]

    def create_relation(self, dst_node, rel_name):
        relation = Relation(src_node=self, dst_node=dst_node, name=rel_name, storage=self.storage,
                            storage_id=self.storage_id)
        relation.save(force=True)

    @property
    def _json(self):
        return {
            NAME: self.name,
            NODE_DATA_TYPE: self.data_type.name,
            NODE_CLASS: self.class_name(),
            NODE_PARENT_CLASS: self.parent_class,
            NODE_ATTRIBUTES: self.json_attributes,
            MENTIONED_TIMES: self.mentioned_times,
            NODE_IMAGE_URLS: self.image_urls
        }

    @property
    def _all_data(self):
        return {
            NAME: self.name,
            NODE_DATA_TYPE: self.data_type.name,
            NODE_CLASS: self.class_name(),
            NODE_PARENT_CLASS: self.parent_class,
            NODE_ATTRIBUTES: self.json_attributes,
            NODE_IMAGE_URLS: self.image_urls
        }

    @staticmethod
    def get_class_by_type(object_class):
        return getattr(sys.modules[__name__], object_class)

    @staticmethod
    def _from_json(data, storage=None, schema_required=None, **kwargs):
        node_class_name = data[NODE_CLASS]
        node_class = Node.get_class_by_type(node_class_name)
        data["index"] = data[OBJECT_ID]
        node: Node = node_class(storage=storage,
                                schema_required=schema_required,
                                **data)
        attributes = data.get(NODE_ATTRIBUTES, {})
        for attribute, values in attributes.items():
            if isinstance(values, list):
                value_set = set(values)
                if len(values) > len(value_set):
                    values = value_set
                for value in values:
                    node.set_attr(attribute, value, force=True)
            else:
                node.set_attr(attribute, values, force=True)
        return node

    @property
    def static_info(self):
        info = super().static_info
        info[MENTIONED_TIMES] = self.mentioned_times
        return info


class ValueNode(Node):
    schema_required = False
    force_accept = False

    def __init__(self, storage_id, prop_name="attr", name=None, aliases=None, index=None, src_index=None, storage=None,
                 **kwargs):
        if index is None:
            index = f"{src_index}_{prop_name}_{name}"
        super(ValueNode, self).__init__(storage_id, index, name, aliases=aliases, storage=storage)
        self.type = NodeTypes.VALUE

    @staticmethod
    def _from_json(data, storage=None, **kwargs):
        return ValueNode(index=data.get(OBJECT_ID),
                         prop_name=data.get(NAME),
                         aliases=data.get(NODE_ALIASES, []),
                         storage=storage,
                         storage_id=data[STORAGE_ID])


class Relation(BaseObject, ABC):
    schema_required = False

    def __init__(self, storage_id, src_node: Node, dst_node: Node, name: str, words=None, storage=None, index=None,
                 schema=None, sentences: List[str] = None, mentioned_time: float = None):
        self.src_node = src_node
        self.dst_node = dst_node
        if index is None:
            index = self.get_relation_id(self.src_node.id, self.dst_node.id, name)
        super(Relation, self).__init__(_id=index, storage=storage, schema=schema, storage_id=storage_id)
        self.name = name
        self.type = RelationTypes.REL
        if words is None:
            words = [self.name]
        else:
            words.append(self.name)
            words = list(set(words))
        self.words = words
        self.sentences = sentences if sentences is not None else {}
        self._p2p_scores = {}
        self._score = 0
        self.mentioned_time = 0

    @property
    def score(self):
        if self._score > EPSILON:
            return self.src_node.score * self._score
        else:
            return self._score

    @score.setter
    def score(self, _score):
        self._score = max([self._score, _score])
        self.dst_node.add_in_relation(self, self._score)
        self.src_node.add_out_relation(self, self._score)

    def set_phase_to_phrase_score(self, src_phrase, dst_phrase, score):
        r_index = f"{src_phrase.index}_{dst_phrase.index}"
        self._p2p_scores[r_index] = max([self._p2p_scores.get(r_index, 0), score])

    @property
    def relation_text(self):
        output = [item for item in self.sentences if self.sentences[item]]
        output = [item.replace(PhraseMask.SRC_MASK, "").replace(PhraseMask.DST_MASK, "").replace("  ", " ").strip()
                  for item in output]
        return output

    @property
    def sents_all_mask(self):
        original_sentences = [item for item in self.sentences if self.sentences[item]]
        output = [item for item in original_sentences]
        for item in original_sentences:
            if self.src_node.name is not None:
                output += [item.replace(PhraseMask.SRC_MASK, name) for name in self.src_node.aliases]
            if self.dst_node.name is not None:
                output += [item.replace(PhraseMask.DST_MASK, name).replace(PhraseMask.SRC_MASK, PhraseMask.DST_MASK)
                           for name in self.dst_node.aliases]
        return list(set(output))

    @property
    def is_filled(self):
        return self.dst_node.name is not None

    @property
    def read_only(self):
        output = self.src_node.read_only or self.dst_node.read_only
        return output

    @property
    def full_info(self):
        return self.src_node.full_info and self.dst_node.full_info

    @classmethod
    def get_relation_id(cls, src_node_id, dst_node_id, name):
        key = f"{src_node_id}-[{name}]->{dst_node_id}"
        return cls.generate_hash(key)

    def __repr__(self):
        return f"({self.src_node.id}) -[{self.name}: {self.type}]-> ({self.dst_node.id})"

    @property
    def _json(self):
        return {
            REL_SRC: self.src_node.id,
            REL_DST: self.dst_node.id,
            NAME: self.name,
            REL_TYPE: self.type.name,
            REL_WORDS: self.words,
            REL_CLASS: self.class_name(),
            REL_MENTIONED_TIME: self.mentioned_time
        }

    @staticmethod
    def get_class_by_type(object_class):
        return getattr(sys.modules[__name__], object_class)

    @staticmethod
    def _from_json(data, storage=None, schema_required=None, nodes: dict = None):
        relation_id = data.get(OBJECT_ID)
        rel_class_name = data[REL_CLASS]
        src_id = data[REL_SRC]
        dst_id = data[REL_DST]
        src_node = nodes.get(src_id)
        dst_node = nodes.get(dst_id)
        name = data[NAME]
        words = data.get(REL_WORDS, [])
        if src_node is None or dst_node is None:
            return

        if rel_class_name == Relation.__name__:
            relation = Relation(index=relation_id, src_node=src_node, dst_node=dst_node, name=name, words=words,
                                storage=storage, storage_id=data[STORAGE_ID])
        else:
            rel_class = Relation.get_class_by_type(rel_class_name)
            relation = rel_class(index=relation_id, src_node=src_node, dst_node=dst_node, relation_id=name, words=words,
                                 storage=storage, storage_id=data[STORAGE_ID])

        src_node.out_relations[relation.id] = relation
        dst_node.in_relations[relation.id] = relation
        return relation

    def detach(self):
        self.src_node.remove_relation(self)
        self.dst_node.remove_relation(self)

    def complete_end_nodes(self):
        src_node, dst_node = self.src_node, self.dst_node
        src_node.out_relations[self.id] = self
        src_node.out_relations_score[self] = 0
        dst_node.in_relations[self.id] = self
        dst_node.in_relations_score[self] = 0

    def save(self, force=False, field_methods=None):
        super().save(force=force)
        self.src_node.save(force=force)
        self.dst_node.save(force=force)


class AttributeRelation(Relation, ABC):
    force_accept = False

    def __init__(self, storage_id: str, src_node: Node, dst_node: Node, name: str, words=None, storage=None,
                 schema=None, sentences: List[str] = None, mentioned_time: float = None):
        super(AttributeRelation, self).__init__(storage_id, src_node, dst_node, name, words, storage=storage,
                                                schema=schema, sentences=sentences, mentioned_time=mentioned_time)
        self.type = RelationTypes.ATTR
        self.mentioned_time = mentioned_time if mentioned_time is not None else float(datetime.now().timestamp())


class RequiredAttributeRelation(AttributeRelation, ABC):

    def __init__(self, storage_id: str, src_node: Node, name: str, words=None, dst_node: Node = None, storage=None,
                 schema=None, sentences: List[str] = None, mentioned_time: float = None):
        dst_node = dst_node if dst_node is not None else ValueNode(src_index=src_node.id, prop_name=name,
                                                                   storage_id=storage_id)
        super(RequiredAttributeRelation, self).__init__(storage_id, src_node, dst_node, name, words, storage=storage,
                                                        schema=schema, sentences=sentences,
                                                        mentioned_time=mentioned_time)
        self.type = RelationTypes.R_ATTR


class OptionalAttributeRelation(AttributeRelation, ABC):
    def __init__(self, storage_id: str, src_node: Node, name: str, words=None, dst_node: Node = None, storage=None,
                 schema=None, sentences: List[str] = None):
        dst_node = dst_node if dst_node is not None else ValueNode(src_index=src_node.id, prop_name=name,
                                                                   storage_id=storage_id)
        super(OptionalAttributeRelation, self).__init__(storage_id, src_node, dst_node, name, words, storage=storage,
                                                        schema=schema, sentences=sentences)
        self.type = RelationTypes.O_ATTR


class Shop(Node):
    def __init__(self, storage_id: str, name: str = None, index=None, aliases=None, storage=None, schema=None,
                 parent_class=None, schema_required=None, bank_accounts: List[Dict] = None, **kwargs):
        super(Shop, self).__init__(index=index, name=name, storage=storage, aliases=aliases, schema=schema,
                                   parent_class=parent_class, schema_required=schema_required, storage_id=storage_id)
        self.parent_class = "shop"
        self.bank_accounts = [] if bank_accounts is None \
            else [BankAccount.from_json(bank_account, storage=self.storage) for bank_account in bank_accounts]

    @property
    def shop_id(self):
        return self.id

    @property
    def shop_name(self):
        return self.name

    def add_product(self, product):
        self.create_relation(product, self.schema)

    def get_random_product(self, k=3):
        products = self.storage.load_random(class_name=Product.class_name(), storage_id=self.storage_id, limit=k,
                                            conditions={NODE_IMAGE_URLS: {"$ne": None}})
        products = [Product.from_json(product_data) for product_data in products]
        return products

    @property
    def _json(self):
        json_data = super()._json
        json_data[BANK_ACCOUNTS] = [bank_account.static_info for bank_account in self.bank_accounts]
        return json_data

    def save(self, force=False, field_methods=None):
        super().save(force=force, field_methods=field_methods)
        [bank_account.save(force=force) for bank_account in self.bank_accounts]


class User(Node):
    def __init__(self, storage_id, index=None, name: str = "default", storage=None, aliases=None, schema=None,
                 parent_class=None, schema_required=None, **kwargs):
        super(User, self).__init__(index=index, name=name, storage=storage, aliases=aliases, schema=schema,
                                   parent_class=parent_class, schema_required=schema_required, storage_id=storage_id)
        self.parent_class = "user"
        self.read_only = False

    @property
    def favor(self):
        return

    @property
    def user_id(self):
        return self.id

    @property
    def user_name(self):
        return self.name

    @property
    def json_attributes(self):
        output = dict()
        for attribute_name in self.schema.all_attributes:
            output[attribute_name] = []
        for r in self.attribute_relations.values():
            if r.name not in output:
                output[r.name] = []
            if r.dst_node.name is not None:
                output[r.name].append([r.dst_node.name, r.mentioned_time])
        for relation_name in output:
            if len(output[relation_name]) > 0:
                output[relation_name].sort(key=lambda item: item[1])
            output[relation_name] = [item[0] for item in output[relation_name]][-3:]
        return output


class Product(Node):
    def __init__(self, storage_id: str, index=None, name: str = "product", storage=None, aliases=None, schema=None,
                 parent_class=None, schema_required=None, code: str = None, mentioned_times: int = None,
                 image_urls: List[str] = None, alias: str = None, **kwargs):
        super(Product, self).__init__(index=index, name=name, storage=storage, aliases=aliases,
                                      parent_class=parent_class, schema=schema, schema_required=schema_required,
                                      storage_id=storage_id, mentioned_times=mentioned_times, image_urls=image_urls)
        self.code = code
        self.alias = alias if alias is not None else self.pre_process_name()

    @classmethod
    def skip_fields(cls):
        return [NODE_IMAGE_FEATURES]

    @property
    def image_url(self):
        if len(self.image_urls) > 0:
            return random.choice(self.image_urls)
        else:
            return ""

    @property
    def image_description(self):
        return f"* image {self.image_url} * {self.name}"

    @property
    def product_id(self):
        return self.id

    @property
    def price(self):
        return self.get_attr("price")

    @property
    def _json(self):
        _json_data = super()._json
        _json_data[CODE] = self.code
        _json_data[NODE_ALIAS] = self.alias
        return _json_data

    @property
    def _all_data(self):
        _json_data = super()._all_data
        _json_data[CODE] = self.code
        _json_data[NODE_ALIAS] = self.alias
        return _json_data


class VariantProduct(Product):
    pass


class BillProduct(Product):
    def __init__(self, storage_id: str, index=None, name: str = "product", storage=None, aliases=None, schema=None,
                 parent_class=None, number: int = None, schema_required=None, code: str = None,
                 status: str = ProductStatus.NONE, image_urls: List[str] = None, **kwargs):
        super(BillProduct, self).__init__(index=index, name=name, storage=storage, aliases=aliases,
                                          parent_class=parent_class, schema=schema, schema_required=schema_required,
                                          storage_id=storage_id, code=code, image_urls=image_urls)
        self.number = number
        self.status = status

    @property
    def multiple_value_attribute(self):
        attrs = [key for key in self.attribute_relations_mapping if
                 key not in ["ảnh", "image", "image_url"] and len(self.attribute_relations_mapping[key]) > 1]
        if len(attrs) > 0:
            attrs.sort()
            return attrs[0]

    @property
    def has_multiple_value_attributes(self):
        return self.multiple_value_attribute is not None

    def set_unique_attr(self, attr: str, value: str = None, force=True):
        self.drop_attr(attr)
        self.set_attr(attr, value, force)

    def get_variant(self, keys_values):
        json_data = self.json
        variant: Product = Product.from_json(json_data)
        for key, value in keys_values.items():
            variant.drop_attr(key)
            variant.set_attr(key, value)
        return variant

    @property
    def confirmed(self):
        return self.status == ProductStatus.CONFIRMED

    @property
    def is_cared(self):
        return self.status == ProductStatus.CARE

    @property
    def is_canceled(self):
        return self.status == ProductStatus.CANCELED

    def care(self):
        if self.status != ProductStatus.CONFIRMED:
            self.status = ProductStatus.CARE

    def confirm(self):
        self.status = ProductStatus.CONFIRMED

    def cancel(self):
        self.status = ProductStatus.CANCELED

    @property
    def product_id(self):
        return self.id

    @property
    def _json(self):
        _json_data = super()._json
        _json_data[BILL_NUMBER_PRODUCTS] = self.number
        _json_data[BILL_STATUS] = self.status
        return _json_data

    @staticmethod
    def from_product(product: Product):
        product_data = product.json
        product_data[BILL_NUMBER_PRODUCTS] = 1
        product_data[CLASS] = BillProduct.class_name()
        output = BillProduct.from_json(product_data, storage=product.storage, schema_required=product.schema_required)
        return output


class BankAccount(Node):
    use_random_key = False

    def __init__(self, storage_id: str, name: str, shop_id: str, owner: str = None, bank: str = None,
                 index=None, storage=None, aliases=None, parent_class=None, schema=None, score=0, update_func=None,
                 schema_required=None, mentioned_times: List[int] = None,
                 verification_method: str = BankVerificationMethod.NONE, **kwargs):
        index = index if index is not None else self.generate_id(f"{self.class_name()}-{shop_id}-{owner}-{bank}")
        super(BankAccount, self).__init__(storage_id=storage_id, index=index, name=name, aliases=aliases,
                                          parent_class=parent_class, schema=schema, score=score,
                                          update_func=update_func, schema_required=schema_required,
                                          mentioned_times=mentioned_times, storage=storage)
        self.owner = owner
        self.bank = bank
        self.shop_id = shop_id
        self.verification_method = verification_method

    @property
    def info_schema(self):
        return {
            BANK_ACCOUNT_BANK: self.bank,
            BANK_ACCOUNT_OWNER: self.owner,
            BANK_ACCOUNT_NUMBER: self.name
        }

    @property
    def _json(self):
        json_data = super()._json
        json_data[BANK_ACCOUNT_OWNER] = self.owner
        json_data[BANK_ACCOUNT_BANK] = self.bank
        json_data[CONV_MESSAGE_SHOP_ID] = self.shop_id
        json_data[BANK_VERIFICATION_METHOD] = self.verification_method
        return json_data

    @property
    def _all_data(self):
        json_data = super()._json
        json_data[BANK_ACCOUNT_OWNER] = self.owner
        json_data[BANK_ACCOUNT_BANK] = self.bank
        json_data[CONV_MESSAGE_SHOP_ID] = self.shop_id
        json_data[BANK_VERIFICATION_METHOD] = self.verification_method
        return json_data


class Bill(Node):
    def __init__(self, storage_id: str, user: User = None, shop: Shop = None, products: List[Dict] = None,
                 index=None, name: str = "bill", storage=None, aliases=None, parent_class=None, schema=None,
                 schema_required=None, status: str = BillStatus.INIT, created_time: int = None,
                 payment: float = None, payment_status: str = PaymentStatus.INIT, bank_account: Dict = None,
                 **kwargs):
        super(Bill, self).__init__(index=index, name=name, storage=storage, aliases=aliases, parent_class=parent_class,
                                   schema=schema, schema_required=schema_required, storage_id=storage_id)
        self.parent_class = "bill"
        self.user = user
        self.shop = shop
        self.bank_account: BankAccount = None if bank_account is None else BankAccount.from_json(bank_account, storage=self.storage)
        products = [BillProduct.from_json(product_data, storage=self.storage) for product_data in
                    products] if products is not None else []
        self._products = {product.id: product for product in products}
        self.status = status
        self.created_time = created_time if created_time is not None else int(datetime.now().timestamp())
        self.payment = payment
        self.payment_status = payment_status

    @property
    def confirmed(self):
        return self.status == BillStatus.CONFIRMED

    @property
    def is_processing(self):
        return self.status == BillStatus.PROCESSING

    def processing(self):
        self.status = BillStatus.PROCESSING

    def confirm(self):
        self.status = BillStatus.CONFIRMED

    def cancel(self):
        self.status = BillStatus.CANCELED

    @property
    def is_empty(self):
        return len(self.products) == 0

    @property
    def info_schema(self):
        return {
            BILL_USER: "{User@name}",
            BILL_SHOP: "{Shop@name}",
            BILL_PRODUCTS: [{NAME: product.name, BILL_NUMBER_PRODUCTS: product.number} for product in self.products
                            if product.confirmed],
            BILL_ADDRESS: "{User@address}",
            BILL_PHONE_NUMBER: "{User@phone_number}",
            BILL_STATUS: "{Bill@delivery_status}",
            BILL_CREATED_TIME: str(datetime.fromtimestamp(self.created_time)),
            BILL_PRICE: "{Bill@price}",
            BILL_PAYMENT: self.payment,
            BILL_PAYMENT_STATUS: self.payment_status,
            BILL_BANK_ACCOUNT: None if self.bank_account is None else self.bank_account.info_schema
        }

    @property
    def products(self):
        return list(self._products.values())

    @products.setter
    def products(self, _products):
        self._products = {product.id: product for product in _products}

    @property
    def confirmed_products(self) -> List[BillProduct]:
        return [p for p in self.products if p.confirmed]

    @staticmethod
    def _from_json(data, storage=None, schema_required=None, **kwargs):
        bill = super()._from_json(data=data, storage=storage, schema_required=schema_required, **kwargs)
        products_data = data.get(BILL_PRODUCTS, [])
        products = [BillProduct.from_json(data=product_data, storage=storage, schema_required=schema_required)
                    for product_data in products_data]
        bill.products = products
        return bill

    @property
    def _json(self):
        json_data = super()._json
        json_data[BILL_USER] = self.user.static_info if self.user is not None else None
        json_data[BILL_SHOP] = self.shop.static_info if self.shop is not None else None
        json_data[BILL_PRODUCTS] = [product.json for product in self.products]
        json_data[BILL_STATUS] = self.status
        json_data[BILL_CREATED_TIME] = self.created_time
        json_data[BILL_PAYMENT] = self.payment
        json_data[BILL_PAYMENT_STATUS] = self.payment_status
        json_data[BILL_BANK_ACCOUNT] = None if self.bank_account is None else self.bank_account.static_info
        return json_data

    @property
    def _all_data(self):
        json_data = super()._all_data
        json_data[BILL_USER] = self.user.json if self.user is not None else None
        json_data[BILL_SHOP] = self.shop.json if self.shop is not None else None
        json_data[BILL_PRODUCTS] = [product.json for product in self.products]
        json_data[BILL_STATUS] = self.status
        json_data[BILL_CREATED_TIME] = self.created_time
        json_data[BILL_PAYMENT] = self.payment
        json_data[BILL_PAYMENT_STATUS] = self.payment_status
        json_data[BILL_BANK_ACCOUNT] = None if self.bank_account is None else self.bank_account.json
        return json_data

    def add_product(self, product: BillProduct):
        if product.id not in self._products:
            self._products[product.id] = product
        return self._products[product.id]

    def get_product(self, product: BillProduct):
        return self._products.get(product.id)

    def save(self, force=False, field_methods=None):
        super().save(self, field_methods=field_methods)


class Weather(Node):
    def __init__(self, storage_id: str, name: str = "weather", index=None, aliases=None, storage=None, schema=None,
                 parent_class=None, schema_required=None, created_time: int = None, location: str = None,
                 date: str = None, **kwargs):
        super(Weather, self).__init__(index=index, name=name, storage=storage, aliases=aliases,
                                      parent_class=parent_class, schema=schema, schema_required=schema_required,
                                      storage_id=storage_id)
        self.read_only = False
        self.created_time = created_time if created_time is not None else int(datetime.now().timestamp())
        self.location = location
        self.date = date

    @property
    def _json(self):
        json_data = super()._json
        json_data[LOCATION] = self.location
        json_data[DATE] = self.date
        return json_data
