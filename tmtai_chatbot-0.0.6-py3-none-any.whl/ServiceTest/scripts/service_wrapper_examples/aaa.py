from TMTChatbot.Common.utils.logging_utils import setup_logging
from TMTChatbot.Common.config import Config
from TMTChatbot.ServiceWrapper import BaseApp
from TMTChatbot.ServiceWrapper.pipeline.base_pipeline import ProcessPipeline, PipelineJob
from TMTChatbot import BaseDataModel
from pydantic import BaseModel


class RouteRequest(BaseModel):
    user_id: str
    product_id: str


class Route1Request(BaseModel):
    user_id: str
    product_id: str
    data: BaseDataModel


class CustomProcessJob(PipelineJob):
    def __init__(self, config: Config = None):
        super(CustomProcessJob, self).__init__(config=config)

    def process_func(self, data):
        data.data["pid"] = self.name
        return data


class CustomProcessPipeline(ProcessPipeline):
    def __init__(self, config: Config = None):
        super(CustomProcessPipeline, self).__init__(config=config)

    def init_workers(self):
        """
        Create n workers of PipelineJob class.
        >>> from TMTChatbot.ServiceWrapper.pipeline.base_pipeline import PipelineJob
        >>> n = self.config.max_process_workers
        >>> self.workers = [PipelineJob(config=self.config) for _ in range(n)]
        :return:
        """
        self.workers = [CustomProcessJob(config=self.config) for _ in range(self.config.max_process_workers)]


if __name__ == "__main__":
    job = CustomProcessPipeline()

    _config = Config()
    _config.default_api_route_prefix = ""
    setup_logging(logging_folder=_config.logging_folder, log_name=_config.log_name)
    app = BaseApp(_config, with_api_app=True, with_kafka_app=False)
    app.api_app.add_endpoint(endpoint='/hello/{user_id}/{product_id}',
                             func=PipelineJob.sample_1,
                             methods=["POST"],
                             description="Hello function",
                             use_thread=True,
                             request_data_model=Route1Request,
                             response_data_model=BaseDataModel,
                             use_async=True)
    app.api_app.add_endpoint('/bye/{user_id}/{product_id}',
                             func=PipelineJob.sample_1,
                             description="Bye function",
                             methods=["POST"],
                             request_data_model=Route1Request,
                             response_data_model=BaseDataModel,
                             use_thread=False,
                             use_async=False)
    app.add_process_function(lambda x: x)
    app.start()
    app.join()
