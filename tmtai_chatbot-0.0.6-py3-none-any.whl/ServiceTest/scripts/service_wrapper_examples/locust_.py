import random
import requests
import json

import torch
from sentence_transformers import SentenceTransformer
from locust import HttpUser, task

data = [
    "cam tan cam lam khanh hoa",
    "6 Ngõ 2 - Đường Thân Nhân Trung, Phù Linh, Sóc Sơn",
    "quận Tân Phú"
]


class LoadTestUser(HttpUser):
    @task
    def get_intent(self):
        # body = {
        #     "data": random.choice(data)
        # }
        body = {
            "index": "e65ba82b-2ba9-5636-902f-b7a368b1f1fa",
            "data": {
                "message": random.choice(data),
                "class": "Message",
                "storage_id": "test"
            }
        }
        url = "http://localhost:8080/process/"
        res = self.client.post(url=url, json=body, timeout=30).json()
