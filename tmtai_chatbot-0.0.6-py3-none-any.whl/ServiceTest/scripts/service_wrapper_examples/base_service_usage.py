import time

from TMTChatbot.ServiceWrapper.services.base_service import (
    BaseServiceSingleton
)
from TMTChatbot.ServiceWrapper.services.base_cache_service import (
    BaseServiceWithRAMCacheSingleton,
    BaseServiceWithCacheSingleton
)
from TMTChatbot.Common.config import Config


class ExampleService(BaseServiceSingleton):
    def __init__(self, config: Config = None):
        super(ExampleService, self).__init__(config)

    def __call__(self, input_data):
        def request_func():
            time.sleep(5)
            return input_data
        output = self.make_request(request_func=request_func, key="some key", postfix="MayBe__call__")
        return output


class ExampleWithRAMService(BaseServiceWithRAMCacheSingleton):
    def __init__(self, config: Config = None):
        super(ExampleWithRAMService, self).__init__(config)

    def __call__(self, input_data):
        def request_func():
            time.sleep(5)
            return input_data
        output = self.make_request(request_func=request_func, key="some key", postfix="MayBe__call__")
        return output


class ExampleWithCacheService(BaseServiceWithCacheSingleton):
    def __init__(self, config: Config = None):
        super(ExampleWithCacheService, self).__init__(config)

    def __call__(self, input_data, key="some key"):
        def request_func():
            time.sleep(5)
            return input_data
        output = self.make_request(request_func=request_func, key=key, postfix="MayBe__call__")
        return output


if __name__ == "__main__":
    import numpy as np
    # _config = Config(cache_host="localhost",
    #                  cache_port="8000",
    #                  cache_endpoint="api/data/",
    #                  cache_endpoint_type="restful")
    _config = Config(cache_host="172.29.13.24",
                     cache_port="20216",
                     cache_endpoint="getdata",
                     cache_endpoint_type="socket")
    # example_service = ExampleService(_config)
    # example_ram_cache_service = ExampleWithRAMService(_config)
    example_cache_service = ExampleWithCacheService(_config)
    time.sleep(5)

    # a = time.time()
    # print(example_service("hello_world"))
    # print("NO RAM CACHE -> sleep 10s every request", time.time() - a)
    #
    # for i in range(5):
    #     a = time.time()
    #     print(example_ram_cache_service("hello_world"))
    #     print("RAM CACHE -> sleep 10s first request and then no sleep with the same key", time.time() - a)

    data = np.array([np.e] * 768) + np.random.rand(768)
    cache_data = {
        "xxx": data.tolist(),
        "yyy": "zzz"
    }
    times = []
    for i in range(50):
        _key = f"xin chào bạn nha {3 if i % 2 == 0 else 4}"
        print(_key, _key in example_cache_service.cache)
        a = time.time()
        _output = example_cache_service(input_data=cache_data, key=_key)
        times.append(time.time() - a)
        print("EXTERNAL CACHE SERVICE -> no sleep every time with the same key", time.time() - a)
        # print(np.sum(np.array(_output) - data))
        # time.sleep(0.5)
        print("-------")
    print(np.mean(times))


