from TMTChatbot.Common.utils.logging_utils import setup_logging
from TMTChatbot.Common.config import Config
from TMTChatbot.ServiceWrapper import BaseApp
from TMTChatbot.ServiceWrapper.services.base_service import BaseServiceSingleton, BaseSingleton
import numpy as np
import pickle
import time

import multiprocessing
from threading import Thread
from multiprocessing.managers import BaseManager
from multiprocessing import Process, Event, Queue, Pool, freeze_support
from uuid import uuid4

from random import choice


from pydantic import BaseModel


class RouteRequest(BaseModel):
    user_id: str
    product_id: str


class Route1Request(BaseModel):
    user_id: str
    product_id: str
    json_data: RouteRequest


def isPointInTri(point, tri_points):
    ''' Judge whether the point is in the triangle
    Method:
        http://blackpawn.com/texts/pointinpoly/
    Args:
        point: [u, v] or [x, y]
        tri_points: three vertices(2d points) of a triangle. 2 coords x 3 vertices
    Returns:
        bool: true for in triangle
    '''
    tp = tri_points

    # vectors
    v0 = tp[:,2] - tp[:,0]
    v1 = tp[:,1] - tp[:,0]
    v2 = point - tp[:,0]

    # dot products
    dot00 = np.dot(v0.T, v0)
    dot01 = np.dot(v0.T, v1)
    dot02 = np.dot(v0.T, v2)
    dot11 = np.dot(v1.T, v1)
    dot12 = np.dot(v1.T, v2)

    # barycentric coordinates
    if dot00*dot11 - dot01*dot01 == 0:
        inverDeno = 0
    else:
        inverDeno = 1/(dot00*dot11 - dot01*dot01)

    u = (dot11*dot02 - dot01*dot12)*inverDeno
    v = (dot00*dot12 - dot01*dot02)*inverDeno

    # check if point in triangle
    return (u >= 0) & (v >= 0) & (u + v < 1)


data = pickle.load(open('input.pickle', 'rb'))


def render_texture(vertices, colors, triangles, h, w, c=3):
    """ render mesh by z buffer
    Args:
        vertices: 3 x nver
        colors: 3 x nver
        triangles: 3 x ntri
        h: height
        w: width
    """
    # initial
    image = np.zeros((h, w, c))

    depth_buffer = np.zeros([h, w]) - 999999.
    # triangle depth: approximate the depth to the average value of z in each vertex(v0, v1, v2), since the vertices
    # are closed to each other
    tri_depth = (vertices[2, triangles[0, :]] + vertices[2, triangles[1, :]] + vertices[2, triangles[2, :]]) / 3.
    tri_tex = (colors[:, triangles[0, :]] + colors[:, triangles[1, :]] + colors[:, triangles[2, :]]) / 3.

    for i in range(triangles.shape[1]):
        tri = triangles[:, i]  # 3 vertex indices

        # the inner bounding box
        u_min = max(int(np.ceil(np.min(vertices[0, tri]))), 0)
        u_max = min(int(np.floor(np.max(vertices[0, tri]))), w - 1)

        v_min = max(int(np.ceil(np.min(vertices[1, tri]))), 0)
        vmax = min(int(np.floor(np.max(vertices[1, tri]))), h - 1)
        if u_max < u_min or vmax < v_min:
            continue

        for u in range(u_min, u_max + 1):
            for v in range(v_min, vmax + 1):
                if tri_depth[i] > depth_buffer[v, u] and isPointInTri([u, v], vertices[:2, tri]):
                    depth_buffer[v, u] = tri_depth[i]
                    image[v, u, :] = tri_tex[:, i]
    return image


def func(user_id: str, product_id: str, json_data: RouteRequest):

    s = time.time()
    render_texture(**data)
    print(f"DONE NNNNNNNN, {time.time() - s}")
    sum_ = 0
    print(user_id, product_id, json_data)
    for i in range(1):
        sum_ += i
    return f"{user_id} is me. I have product {product_id}, {sum_}"


class Data0:
    def __init__(self, i):
        self.i = i


class Data(BaseSingleton):
    def __init__(self):
        super(Data, self).__init__()
        self.data = {str(i): Data0(i) for i in range(1000000)}

    def __getitem__(self, i):
        return self.data[i].i


# class MyJob(Process):
#     def __init__(self, name: str = "xx"):
#         super(MyJob, self).__init__(name=name, daemon=True)
#         self.in_q = Queue()
#         self.out_q = Queue()
#
#     def run(self) -> None:
#         def func(user_id: str, product_id: str):
#             sum_ = 0
#             for i in range(1):
#                 sum_ += i
#             return f"{user_id} is me. I have product {product_id}, {sum_}"
#
#         while True:
#             try:
#                 jid, input_data = self.in_q.get(timeout=5, block=True)
#                 uid = input_data["uid"]
#                 pid = input_data["pid"]
#                 print(f"NEW {self.name}")
#                 print(jid, uid, pid)
#             except:
#                 print("pass")
#                 continue
#             output = func(uid, pid)
#             print("OUT", output)
#             self.out_q.put((jid, output))
#             print("DONE", jid)
#
#
# class Job(BaseServiceSingleton):
#     def __init__(self):
#         super(Job, self).__init__()
#         self.workers = []
#         # shared_queue = m.Queue()
#         # shared_queue_ = m.Queue()
#         # # create many child processes
#         # n_tasks = 50
#         # processes = [Process(target=self.run, args=(i, shared_queue, shared_queue_)) for i in range(n_tasks)]
#         # for process in processes:
#         #     process.start()
#         self.data = Data()
#         for i in range(5):
#             worker = MyJob(name=str(i))
#             self.workers.append(worker)
#         for process in self.workers:
#             process.start()
#
#         # self.thread = Thread(target=self.gather_result)
#         # self.thread.start()
#         self.storage = {}
#
#     def gather_result(self):
#         while True:
#             print("xxx")
#             import time
#             time.sleep(1)
#
#     def run(self, i, in_q: Queue, out_q: Queue):
#         def func(user_id: str, product_id: str):
#             sum_ = 0
#             for i in range(100000000):
#                 sum_ += i
#             return f"{user_id} is me. I have product {product_id}, {sum_}"
#
#         while True:
#             try:
#                 jid, (uid, pid) = in_q.get(timeout=5, block=True)
#                 print(f"NEW {i}")
#                 print(jid, uid, pid)
#             except:
#                 continue
#             output = func(uid, pid)
#             print("OUT", output)
#             out_q.put((jid, output))
#             print("DONE", jid)
#
#     def process(self, input_data):
#         jid = str(uuid4())
#         event = Event()
#         event.clear()
#         self.storage[jid] = {
#             "output": None,
#             "flag": event
#         }
#         print(input_data)
#         worker = choice(self.workers)
#         worker.in_q.put((jid, input_data))
#         # worker["in_queue"].put((jid, input_data))
#         _jid, _output = worker.out_q.get()
#         self.storage[_jid]["output"] = _output
#         self.storage[_jid]["flag"].set()
#
#         event.wait()
#         output = self.storage[jid]["output"]
#         return output
#
#
# def wait_func(user_id: str, product_id: str, json_data):
#     output = job.process({
#         "uid": user_id,
#         "pid": product_id
#     })
#     return output


# for i in range(5):
#
#     s_ = time.time()
#     render_texture(**data)
#     print("xxxyyyyyyyyyyyyyyyyyyyyy", time.time() - s_)


if __name__ == "__main__":
    # job = Job()
    from TMTChatbot.ServiceWrapper.interfaces.restful.routes.base_route import BaseRoute

    freeze_support()
    _config = Config()
    _config.default_api_route_prefix = ""
    setup_logging(logging_folder=_config.logging_folder, log_name=_config.log_name)
    app = BaseApp(_config, with_api_app=True, with_kafka_app=False, with_default_pipeline=False)
    # route = BaseRoute(prefix="/bye", config=_config)
    # route.add_endpoint("/{user_id}/{product_id}", func=func, methods=["POST"], custom_data_model=Route1Request,
    #                    use_thread=False, use_async=False)
    # app.api_app.app.include_router(route.router)
    app.api_app.add_endpoint('/hello/{user_id}/{product_id}', func=func, methods=["POST"],
                             request_data_model=Route1Request, use_thread=False, use_async=False)
    # app.api_app.add_endpoint('/bye/{user_id}/{product_id}', func=func, methods=["POST"],
    #                          custom_data_model=Route1Request, use_thread=False, use_async=False)
    app.start()
    app.join()
