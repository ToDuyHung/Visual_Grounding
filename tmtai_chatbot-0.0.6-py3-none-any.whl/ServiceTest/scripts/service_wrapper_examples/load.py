import requests
import json
import time
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor

url = "http://172.29.13.24:20234/process/address_suggest"

payload = json.dumps({
    "data": "cam tan cam lam khanh hoa"
})

# payload = json.dumps({
#     "data": {
#         "xxx": "xxx"
#     }
# })
headers = {
    'Content-Type': 'application/json'
}

# sessions = [requests.session() for _ in range(500)]
sessions = [requests.session() for _ in range(1)]
times = 0
n = 0


def make_data(idx):
    global session
    global times
    global n
    s = time.time()
    done = False
    while not done:
        try:
            response = sessions[idx % 1].post(url, headers=headers, data=payload, timeout=5)
            response.text
            done = True
        except Exception as e:
            print("retry", e)
            continue
    x = time.time() - s
    # print(f"{idx}, \t, {total_time}")
    times += x
    n += 1
    # print(f"{times / n} | {n/times} | {times} | {n} | {x}")
    return True


for i in range(5):
    make_data(i)

k = 1000000
start_time = time.time()
with ThreadPoolExecutor(max_workers=500) as executor:
    jobs = []
    for i in range(k):
        jobs.append(executor.submit(make_data, i))

    # bar = tqdm(total=len(jobs))
    for job in tqdm(jobs):
        job.result()
        # bar.update(1)

print("TOTAL TIME", time.time() - start_time)
