

from TMTChatbot.Common.config import Config
from TMTChatbot.Common.storage.mongo_client import MongoConnector
from TMTChatbot.Schema.objects.graph.graph_data import Shop, BankAccount
from TMTChatbot.Schema.common.product_types import BankVerificationMethod


_config = Config(mongo_host="172.29.13.24", mongo_port=20253, mongo_username="admin", mongo_password="admin")
storage = MongoConnector(config=_config)


shop: Shop = Shop.from_json({
    "class": Shop.class_name(),
    "storage_id": "test",
    "_id": "f853c5c9-b7a5-5220-82a1-1c1a94777e4e"
}, storage=storage)

bank_account_1 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="Sacombank",
                             owner="TMT Sacombank", shop_id=shop.id, verification_method=BankVerificationMethod.IMAGE)
bank_account_2 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="Techcombank",
                             owner="TMT Techcombank", shop_id=shop.id, verification_method=BankVerificationMethod.IMAGE)
bank_account_3 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="Vietcombank",
                             owner="TMT Vietcombank", shop_id=shop.id, verification_method=BankVerificationMethod.IMAGE)
bank_account_4 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="Vietinbank",
                             owner="TMT Vietinbank", shop_id=shop.id, verification_method=BankVerificationMethod.IMAGE)
bank_account_5 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="Momo", owner="TMT Mono",
                             shop_id=shop.id, verification_method=BankVerificationMethod.NONE)
bank_account_6 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="ZaloPay",
                             owner="TMT ZaloPay", shop_id=shop.id, verification_method=BankVerificationMethod.NONE)
bank_account_7 = BankAccount(storage_id="test", name="0xxxxxx0xxxxxx", storage=storage, bank="ZaloPay",
                             owner="TMT ZaloPay", shop_id=shop.id, verification_method=BankVerificationMethod.NONE)

shop.bank_accounts = [bank_account_1, bank_account_2, bank_account_3, bank_account_4, bank_account_5, bank_account_6]
shop.save(force=True)
