from typing import List
from TMTChatbot.StateController.config import ConversationConfig

from TMTChatbot.Schema.objects.conversation.conversation import Conversation
from TMTChatbot.Common.storage.mongo_client import MongoConnector


if __name__ == "__main__":
    _config = ConversationConfig(intent_url="http://172.29.13.24:20221",
                                 graph_qa_url="http://172.29.13.24:20224",
                                 ner_url="http://172.29.13.24:20220",
                                 doc_qa_url="http://172.29.13.24:20227",
                                 node_search_url="http://172.29.13.24:20223",
                                 # node_search_url="http://localhost:8080",
                                 multiple_choice_url="http://172.29.13.24:20230",
                                 mongo_host="172.29.13.24",
                                 mongo_port=20253,
                                 address_url="http://address.ai.tmtco.org/process/ner_address",
                                 response_delimiter="\n")

    storage = MongoConnector(config=_config)
    conversations: List[Conversation] = Conversation.load_all(storage=storage, storage_id="test")
    output = []
    # for conversation in conversations:
    #     text = "\n".join([item.replace("\n", ".") for item in conversation.history_text])
    #     output.append(text)
    #
    # output = "\n\n".join(output)
    # with open("ServiceTest/scripts/schema_examples/conversations.txt", "w", encoding="utf8") as f:
    #     f.write(output)
