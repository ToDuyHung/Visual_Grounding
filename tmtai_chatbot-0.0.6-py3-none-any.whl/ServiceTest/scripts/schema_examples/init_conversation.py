from TMTChatbot.Schema.objects.conversation.conversation import Conversation
from TMTChatbot.Schema.objects.graph.graph_data import Shop, User, Product
from TMTChatbot.Common.storage.mongo_client import MongoConnector


if __name__ == "__main__":
    import json
    from TMTChatbot.Common.utils import setup_logging
    from TMTChatbot.Common.config import Config

    _config = Config()
    storage = MongoConnector(_config)

    storage_id = "test"

    setup_logging(logging_folder="./logs", log_name="app.log")
    _shop = Shop(index="f853c5c9-b7a5-5220-82a1-1c1a94777e4e", name="SHOP abc", aliases=["ABC"], storage=storage,
                 storage_id=storage_id)
    shirt = Product(index="271d550b-a7c8-5334-851e-e27198c2bf2f", name="áo sơ mi", aliases=["sơ mi"],
                    parent_class="Shirt", storage=storage, storage_id=storage_id)
    shirt.set_attr("colors", "red")
    jean = Product(index="66008175-e4f8-5bdd-8574-087fb547fe67", name="quần jean", aliases=["jean", "quần bò"],
                   parent_class="Jean",
                   storage=storage, storage_id=storage_id)
    hat = Product(index="bcec22de-7032-5816-99e3-62dca7dbb57b", name="mủ", aliases=["mủ lưỡi trai"], parent_class="Hat",
                  storage=storage, storage_id=storage_id)
    _user = User(index="0c5b6cdc-f01e-50b1-8780-1e4f5ecc69c2", name="User XYZ", aliases=["xyz"], storage=storage,
                 storage_id=storage_id)
    _shop.create_relation(shirt, "own")
    _shop.create_relation(jean, "own")
    _shop.create_relation(hat, "own")
    conversation = Conversation("1", shop=_shop, user=_user, storage=storage, storage_id=storage_id)
    print(conversation.data.nodes)
    conversation.save(force=True)
    json_data = conversation.json
    json_string = json.dumps(json_data, indent=4)
    print(json_string)
    new_conversation: Conversation = Conversation.from_json(json_data, storage=storage)
    json_data = new_conversation.json
    _json_string = json.dumps(json_data, indent=4)
    print(_json_string)
    print(json_string == _json_string)
    new_conversation.save(force=True)
    print(new_conversation.data.nodes)
    print(new_conversation.states)
    print(conversation.states)


