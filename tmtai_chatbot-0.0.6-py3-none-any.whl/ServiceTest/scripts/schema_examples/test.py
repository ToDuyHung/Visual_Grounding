import re

myString = "This is my tweet check it out https://example.com/blah=?sssss%20   https://example.com/blah=?sssss%21"

a = list(re.findall("(?P<url>https?://[^\s]+)", myString))
print(type(a))
print(a)

from vncorenlp import VnCoreNLP

annotator = VnCoreNLP(address='http://172.29.13.24', port=20215, timeout=30, annotators='wseg,pos,ner,parse')
