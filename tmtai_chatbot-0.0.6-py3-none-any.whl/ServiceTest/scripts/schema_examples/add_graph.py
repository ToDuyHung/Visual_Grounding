from TMTChatbot.Schema.objects.graph.graph_data import Shop, User, Product
from TMTChatbot.Schema.objects.graph.graph import SubGraph
from TMTChatbot.Common.storage.mongo_client import MongoConnector
import json


if __name__ == "__main__":
    from TMTChatbot.Common.utils import setup_logging
    from TMTChatbot.Common.config import Config

    _config = Config()
    storage = MongoConnector(_config)
    storage_id = "test"
    setup_logging(logging_folder="./logs", log_name="app.log")
    _shop = Shop(name="SHOP abc", aliases=["ABC"], storage=storage, storage_id=storage_id)
    # shirt = Product(name="áo sơ mi", aliases=["sơ mi"], parent_class="Shirt", storage=storage, storage_id=storage_id)
    # shirt.set_attr("colors", "red")
    # jean = Product(name="quần jean", aliases=["jean", "quần bò"], parent_class="Jean",
    #                storage=storage, storage_id=storage_id)
    # hat = Product(name="mủ", aliases=["mủ lưỡi trai"], parent_class="Hat", storage=storage, storage_id=storage_id)
    _user = User(name="User XYZ", aliases=["xyz"], storage=storage, storage_id=storage_id)
    # _shop.create_relation(shirt, "own")
    # _shop.create_relation(jean, "own")
    # _shop.create_relation(hat, "own")
    graph = SubGraph.from_json(json.load(open("ServiceTest/scripts/schema_examples/test_data.json", "r", encoding="utf8")), storage=storage)

    # graph = SubGraph(nodes=[_shop, _user], shop=_shop, user=_user, storage=storage, storage_id=storage_id)

    # Only force = True can save data graph
    graph.save(force=True)
    # force = False will not make change to database

