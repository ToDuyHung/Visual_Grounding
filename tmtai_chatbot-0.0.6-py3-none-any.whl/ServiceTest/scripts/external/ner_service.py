from typing import List

from TMTChatbot import BaseExternalService, BaseDataModel, Message, NerTag

from config.config import Config


class NERService(BaseExternalService):
    def __init__(self, config: Config = None):
        super(NERService, self).__init__(config=config)
        self.session = None
        self.api_url = f"{self.config.ner_url}/process"

    def _pre_process(self, input_data: Message):
        return BaseDataModel(data=input_data.all_data)

    def _post_process(self, data: BaseDataModel) -> List[NerTag]:
        if data is not None:
            result = data.data.get("entities", [])
            result = [NerTag(**item) for item in result]
        else:
            result = []
        return result

    def __call__(self, input_data: Message, key=None, postfix="", num_retry: int = None, call_prop: float = 0):
        if self.api_possible():
            if input_data.entities is not None and len(input_data.entities) > 0:
                return input_data
            data = self._pre_process(input_data)
            result: BaseDataModel = self.make_request(lambda: self._call_api(data), key=key, postfix=postfix,
                                                      num_retry=num_retry, call_prop=call_prop)
            output: List[NerTag] = self._post_process(result)
            input_data.entities = output
            if result is None:
                self.api_alive = False
            else:
                self.api_alive = True
            return input_data
