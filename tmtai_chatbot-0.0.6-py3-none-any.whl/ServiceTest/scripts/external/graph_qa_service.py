from TMTChatbot import (
    BaseExternalService,
    BaseDataModel,
    Conversation
)

from config.config import Config


class GraphQAService(BaseExternalService):
    def __init__(self, config: Config = None):
        super(GraphQAService, self).__init__(config=config)
        self.session = None
        self.api_url = f"{self.config.graph_qa_url}/process"

    def _pre_process(self, input_data: Conversation):
        graph_data = input_data.data.all_data
        graph_data["question"] = input_data.current_state.message.message
        return BaseDataModel(data=graph_data)

    def _post_process(self, data: BaseDataModel) -> str:
        if data is not None:
            result = data.data.get("answer", "")
        else:
            result = ""
        return result

